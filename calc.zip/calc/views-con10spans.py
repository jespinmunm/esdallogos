from django.shortcuts import render, redirect
from django.http import HttpResponse
import numpy as np
import simplejson as json
import json
from datetime import datetime
from pymongo import MongoClient

from django.contrib.auth import (
    authenticate,
    get_user_model,
    login,
    logout
    )
from .forms import UserLoginForm, UserRegisterForm
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.decorators import login_required


uri = "mongodb://calcdb:TwcY7EK3IRgMClKIY5LLpDJagE2BbNNWA6ZD3vd4CKNLtD82tTav00wInkUhG9m05NBgq4Bf2EAtikfc5MqGDA==@calcdb.mongo.cosmos.azure.com:10255/?ssl=true&replicaSet=globaldb&maxIdleTimeMS=120000&appName=@calcdb@&retrywrites=false"

try:
        connect = MongoClient(uri)
        print("DB connection works!!")
except:
        print("DB connection failed")

db = connect.demoDB
collection = db.demoCollection



databaseHJ=[[None for c in range(3)] for r in range(10)]
databaseHJ[0][0]='23754'
databaseHJ[0][1]=5
databaseHJ[0][2]=2


@login_required
def test(request):
    return render(request, 'test.html')

def summary_recalculate(request):
    global d_current_status
    global d_HB_or_SV
    global d_HB_or_SV_value
    global d_r_St_type
    global d_r_HB1
    global d_r_text_HB
    global d_r_HB2
    global d_r_d_result_HB
    global d_r_SHR1
    global d_r_text_SHR
    global d_r_SHR2
    global d_r_d_result_SHR
    global d_r_text_HB_pin
    global d_r_text_SHR_pin
    global d_r_HB1_pin
    global d_r_SHR1_pin
    global d_r_HB2_pin
    global d_r_SHR2_pin
    global d_r_d_result_HB_pin
    global d_r_d_result_SHR_pin
    global d_r_text_HB_fix
    global d_r_text_SHR_fix 
    global d_r_HB1_fix 
    global d_r_SHR1_fix 
    global d_r_HB2_fix
    global d_r_SHR2_fix 
    global d_r_d_result_HB_fix 
    global d_r_d_result_SHR_fix 
    global d_fallaContinouos
    global d_r_HB1_hjs 
    global d_r_SHR1_hjs 
    global d_r_HB2_hjs 
    global d_r_SHR2_hjs 
    global d_r_d_result_HB_hjs
    global d_r_d_result_SHR_hjs 
    global d_r_Result_HJ_hjs 
    global d_r_text_HB_hjs 
    global d_r_text_SHR_hjs
    global d_current_status_hb 
    global d_current_status_shr 
    global d_sf 
    global d_Span_SVRating
    global d_estructure_Type_convert 
    global d_current_status_hb_hjs 
    global d_current_status_shr_hjs
    global d_ldds_f 
    global d_ldds_position_f 
    global valid_data 
    global d_extra_check_hj



    global d_current_status_localRecalculate
    global d_HB_or_SV_localRecalculate
    global d_HB_or_SV_value_localRecalculate
    global d_r_St_type_localRecalculate
    global d_r_HB1_localRecalculate
    global d_r_text_HB_localRecalculate
    global d_r_HB2_localRecalculate
    global d_r_d_result_HB_localRecalculate
    global d_r_SHR1_localRecalculate
    global d_r_text_SHR_localRecalculate
    global d_r_SHR2_localRecalculate
    global d_r_d_result_SHR_localRecalculate
    global d_r_text_HB_pin_localRecalculate
    global d_r_text_SHR_pin_localRecalculate
    global d_r_HB1_pin_localRecalculate
    global d_r_SHR1_pin_localRecalculate
    global d_r_HB2_pin_localRecalculate
    global d_r_SHR2_pin_localRecalculate
    global d_r_d_result_HB_pin_localRecalculate
    global d_r_d_result_SHR_pin_localRecalculate
    global d_r_text_HB_fix_localRecalculate
    global d_r_text_SHR_fix_localRecalculate 
    global d_r_HB1_fix_localRecalculate 
    global d_r_SHR1_fix_localRecalculate 
    global d_r_HB2_fix_localRecalculate
    global d_r_SHR2_fix_localRecalculate 
    global d_r_d_result_HB_fix_localRecalculate 
    global d_r_d_result_SHR_fix_localRecalculate 
    global d_fallaContinouos_localRecalculate
    global d_r_HB1_hjs_localRecalculate 
    global d_r_SHR1_hjs_localRecalculate 
    global d_r_HB2_hjs_localRecalculate 
    global d_r_SHR2_hjs_localRecalculate 
    global d_r_d_result_HB_hjs_localRecalculate
    global d_r_d_result_SHR_hjs_localRecalculate 
    global d_r_Result_HJ_hjs_localRecalculate 
    global d_r_text_HB_hjs_localRecalculate 
    global d_r_text_SHR_hjs_localRecalculate
    global d_current_status_hb_localRecalculate 
    global d_current_status_shr_localRecalculate 
    global d_sf_localRecalculate 
    global d_Span_SVRating_localRecalculate
    global d_estructure_Type_convert_localRecalculate 
    global d_current_status_hb_hjs_localRecalculate 
    global d_current_status_shr_hjs_localRecalculate
    global d_ldds_f_localRecalculate 
    global d_ldds_position_f_localRecalculate 
    global valid_data_localRecalculate 
    global d_extra_check_hj_localRecalculate
    


    for x in range(1,total_structures+1):
        try:
            d_current_status[x]=d_current_status_localRecalculate[x]
        except:
            pass
        try:
            d_HB_or_SV[x]=d_HB_or_SV_localRecalculate[x]
        except:
            pass
        try:
            d_HB_or_SV_value[x]=d_HB_or_SV_value_localRecalculate[x]
        except:
            pass
        try:
            d_r_St_type[x]=d_r_St_type_localRecalculate[x]
        except:
            pass
        try:
            d_r_HB1[x]=d_r_HB1_localRecalculate[x]
        except:
            pass
        try:
            d_r_text_HB[x]=d_r_text_HB_localRecalculate[x]
        except:
            pass
        try:
            d_r_HB2[x]=d_r_HB2_localRecalculate[x]
        except:
            pass
        try:
            d_r_d_result_HB[x]=d_r_d_result_HB_localRecalculate[x]
        except:
            pass
        try:
            d_r_SHR1[x]=d_r_SHR1_localRecalculate[x]
        except:
            pass
        try:
            d_r_text_SHR[x]=d_r_text_SHR_localRecalculate[x]
        except:
            pass
        try:
            d_r_SHR2[x]=d_r_SHR2_localRecalculate[x]
        except:
            pass
        try:
            d_r_d_result_SHR[x]=d_r_d_result_SHR_localRecalculate[x]
        except:
            pass
        try:
            d_r_text_HB_pin[x]=d_r_text_HB_pin_localRecalculate[x]
        except:
            pass
        try:
            d_r_text_SHR_pin[x]=d_r_text_SHR_pin_localRecalculate[x]
        except:
            pass
        try:
            d_r_HB1_pin[x]=d_r_HB1_pin_localRecalculate[x]
        except:
            pass
        try:
            d_r_SHR1_pin[x]=d_r_SHR1_pin_localRecalculate[x]
        except:
            pass
        try:
            d_r_HB2_pin[x]=d_r_HB2_pin_localRecalculate[x]
        except:
            pass
        try:
            d_r_SHR2_pin[x]=d_r_SHR2_pin_localRecalculate[x]
        except:
            pass
        try:
            d_r_d_result_HB_pin[x]=d_r_d_result_HB_pin_localRecalculate[x]
        except:
            pass
        try:
            d_r_d_result_SHR_pin[x]=d_r_d_result_SHR_pin_localRecalculate[x]
        except:
            pass
        try:
            d_r_text_HB_fix[x]=d_r_text_HB_fix_localRecalculate[x]
        except:
            pass
        try:
            d_r_text_SHR_fix[x]=d_r_text_SHR_fix_localRecalculate[x]
        except:
            pass
        try:
            d_r_HB1_fix[x]=d_r_HB1_fix_localRecalculate[x]
        except:
            pass




        



        try:
            d_r_SHR1_fix[x]=d_r_SHR1_fix_localRecalculate[x]
        except:
            pass
        try:
            d_r_HB2_fix[x]=d_r_HB2_fix_localRecalculate[x]
        except:
            pass
        try:
            d_r_SHR2_fix[x]=d_r_SHR2_fix_localRecalculate[x]
        except:
            pass
        try:
            d_r_d_result_HB_fix[x]=d_r_d_result_HB_fix_localRecalculate[x]
        except:
            pass
        try:
            d_r_d_result_SHR_fix[x]=d_r_d_result_SHR_fix_localRecalculate[x]
        except:
            pass
        try:
            d_fallaContinouos[x]=d_fallaContinouos_localRecalculate[x]
        except:
            pass
        try:
            d_r_HB1_hjs[x]=d_r_HB1_hjs_localRecalculate[x]
        except:
            pass



        


        try:
            d_r_SHR1_hjs[x]=d_r_SHR1_hjs_localRecalculate[x]
        except:
            pass
        try:
            d_r_HB2_hjs[x]=d_r_HB2_hjs_localRecalculate[x]
        except:
            pass
        try:
            d_r_SHR2_hjs[x]=d_r_SHR2_hjs_localRecalculate[x]
        except:
            pass
        try:
            d_r_d_result_HB_hjs[x]=d_r_d_result_HB_hjs_localRecalculate[x]
        except:
            pass
        try:
            d_r_d_result_SHR_hjs[x]=d_r_d_result_SHR_hjs_localRecalculate[x]
        except:
            pass
        try:
            d_r_Result_HJ_hjs[x]=d_r_Result_HJ_hjs_localRecalculate[x]
        except:
            pass
        try:
            d_r_text_HB_hjs[x]=d_r_text_HB_hjs_localRecalculate[x]
        except:
            pass
        try:
            d_r_text_SHR_hjs[x]=d_r_text_SHR_hjs_localRecalculate[x]
        except:
            pass

        

        try:
            d_current_status_hb[x]=d_current_status_hb_localRecalculate[x]
        except:
            pass

        try:
            d_current_status_shr[x]=d_current_status_shr_localRecalculate[x]
        except:
            pass
        try:
            d_sf[x]=d_sf_localRecalculate[x]
        except:
            pass
        try:
            d_Span_SVRating[x]=d_Span_SVRating_localRecalculate[x]
        except:
            pass
        try:
            d_estructure_Type_convert[x]=d_estructure_Type_convert_localRecalculate[x]
        except:
            pass
        try:
            d_current_status_hb_hjs[x]=d_current_status_hb_hjs_localRecalculate[x]
        except:
            pass
        try:
            d_current_status_shr_hjs[x]=d_current_status_shr_hjs_localRecalculate[x]
        except:
            pass
        try:
            d_ldds_f[x]=d_ldds_f_localRecalculate[x]
        except:
            pass
        try:
            d_ldds_position_f[x]=d_ldds_position_f_localRecalculate[x]
        except:
            pass
        try:
            valid_data[x]=valid_data_localRecalculate[x]
        except:
            pass        
        try:
            d_extra_check_hj[x]=d_extra_check_hj_localRecalculate[x]
        except:
            pass
        




    print("d_current_status_localRecalculate")
    print(d_current_status_localRecalculate)
    print("d_current_status")
    print(d_current_status)
    print("d_r_St_type_localRecalculate")
    print(d_r_St_type_localRecalculate)
    print("d_r_St_type")
    print(d_r_St_type)



    global_fail=0

    for x in range(1,total_structures+1):
        if (d_current_status[x]=='FAIL'):
            global_fail=1
    if global_fail==0:
        global_status='OK'
    else:
        global_status='FAIL'


    matrix_output=[[None for c in range(3)] for r in range(total_structures)]
    i=-1
    for key in d_StructureKey:
        i=i+1
        matrix_output[i][0]=key
        matrix_output[i][1]=d_StructureKey[key]

    i=-1
    for key in d_current_status:
        i=i+1
        matrix_output[i][2]=d_current_status[key]





    #return render(request, 'summary.html')
    return render(request, 'summary.html',{'matrix_output':matrix_output,'global_status':global_status})


def recalculate(request):
        print("::::::::::::::::: RECALCULATE :::::::::::::::::::::::::")
        global MaxMoveMomHB11
        global MaxMoveMomHB22
        global MaxMoveShrHB11
        global MaxMoveShrHB22

        global HB_rating
        global Reserve_Factor

        global d_StructureKey

        global d_HB_or_SV_value
        global d_HB_or_SV
        global workssheetLB4coma2masI
        global d_workssheetLB4coma2masI
        global workssheetLB5coma2masI
        global d_workssheetLB5coma2masI

        global OPTlhfixed
        global OPTlhpin
        global OPTrhfixed
        global OPTrhpin

        global sf

        d_r_HB1={}
        d_r_SHR1={}
        d_r_HB2={} 
        d_r_SHR2={} 
        d_r_d_result_HB={} 
        d_r_d_result_SHR={}


        d_r_HB1_pin={} 
        d_r_SHR1_pin={} 
        d_r_HB2_pin={} 
        d_r_SHR2_pin={} 
        d_r_d_result_HB_pin={} 
        d_r_d_result_SHR_pin={}

        d_r_HB1_fix={}
        d_r_SHR1_fix={} 
        d_r_HB2_fix={} 
        d_r_SHR2_fix={} 
        d_r_d_result_HB_fix={} 
        d_r_d_result_SHR_fix={}

        d_r_HB1_hjs={} 
        d_r_SHR1_hjs={} 
        d_r_HB2_hjs={} 
        d_r_SHR2_hjs={} 
        d_r_d_result_HB_hjs={} 
        d_r_d_result_SHR_hjs={}
        d_r_Result_HJ_hjs={}

        d_r_fallaContinouos={}
        d_r_St_type={}



        ####return variables#####
        d_r_text_HB={}
        d_r_text_m_HB={}

        d_r_text_SHR={}
        d_r_text_m_SHR={}
        d_current_status={}

        d_r_text_HB_pin={}
        d_r_text_SHR_pin={}
        d_current_status_pin={}

        d_r_text_HB_fix={}
        d_r_text_SHR_fix={}
        d_current_status_fix={}
        d_fallaContinouos={}

        d_r_text_HB_hjs={}
        d_r_text_SHR_hjs={}

        d_current_status_hb={}
        d_current_status_shr={}

        d_sf={}
        d_estructure_Type_convert={}

        d_current_status_hb_hjs={}
        d_current_status_shr_hjs={}

        d_extra_check_hj={}

        d_ldds_f={}
        d_ldds_position_f={}




        globalvariables()



        ##########inputs variables#######
        sf=0.99
        St_type="2"
        HB_or_SV="HB"
        HB_rating=45
        Reserve_Factor=0


        ##################################
        d_r_St_type[structure]=St_type
        T_E=structure

        d_HB_or_SV[T_E]=HB_or_SV
        d_HB_or_SV_value[T_E]=HB_rating


        d_r_St_type[T_E]=St_type

        d_r_St_type[T_E]=St_type
        d_sf[T_E]=sf



        workssheetLB4coma2masI=d_workssheetLB4coma2masI[T_E]
        workssheetLB5coma2masI=d_workssheetLB5coma2masI[T_E]
        if(St_type=="1"):      
            d_estructure_Type_convert[T_E]='Continuous'     
            #####botones#####3
            OPTlhfixed=0
            OPTlhpin=1
            OPTrhfixed=0
            OPTrhpin=1           


            PREPARE_CALCS()

            if(HB_or_SV=="HB"):
                MaxMoveMomHB1,MaxMoveShrHB1=Load_Vehicle_HB_Fact()
            elif(HB_or_SV=='SV'):
                MaxMoveMomHB1,MaxMoveShrHB1=Load_Vehicle_SV_Fact()

            for I in range(1, 26):
                for J in range(1, 7):
                    MaxMoveMomHB11[I, J] = MaxMoveMomHB1[I, J]

            for I in range(1, 26):
                for J in range(1, 6):
                    MaxMoveShrHB11[I, J] = MaxMoveShrHB1[I, J]

            L=np.zeros(11)
            EIStrt=np.zeros(11)
            Lleft=np.zeros(11)
            EI=np.zeros(11)
            KEI=np.zeros((11,3))
            FEM=np.zeros((11,3))
            Vehicle=np.zeros((51,3))
            Loadin=np.zeros((6,101))
            FEM1=np.zeros((11,3))
            FEM2=np.zeros((11,3))
            Rv=np.zeros(12)
            MaxMoveMomHB=np.zeros((26,7))        
            MaxMoveShrHB=np.zeros((26,6))
            workssheetLB6coma2masI=np.zeros(11)
            MaxMoveMom=np.zeros((43,4))
            MaxMoveShr=np.zeros((26,3))
            OpeninFlag=0########?????
            
            workssheetLB3coma2masI=np.zeros(11)


            PREPARE_CALCS()
            MaxMoveMomHB2, MaxMoveShrHB2=Load_Axles_AIL()

            for I in range(1, 26):
                for J in range(1, 7):
                    MaxMoveMomHB22[I, J] = MaxMoveMomHB2[I, J]

            for I in range(1, 26):
                for J in range(1, 6):
                    MaxMoveShrHB22[I, J] = MaxMoveShrHB2[I, J]


            HB1, SHR1, HB2, SHR2, d_result_HB, d_result_SHR =comparative(MaxMoveMomHB11, MaxMoveMomHB22,MaxMoveShrHB11,MaxMoveShrHB22)

            d_r_HB1[T_E]=HB1
            d_r_SHR1[T_E]=SHR1
            d_r_HB2[T_E]=HB2
            d_r_SHR2[T_E]=SHR2
            d_r_d_result_HB[T_E]=d_result_HB
            d_r_d_result_SHR[T_E]=d_result_SHR

           

            ##################################### RETURN VALUES ########################            
            ######## HB1 ########
            v_text_m_HB=[]
            i=1           
            nciclos=int(len(d_r_HB1[T_E])/2)
            for i in range(1,nciclos+1):
                a="Mom at sup " + str(i)
                b="Mom at span " + str(i)
                v_text_m_HB.append(a)
                v_text_m_HB.append(b)
            c="Mom at sup " + str(i+1)
            v_text_m_HB.append(c)

            d_r_text_HB[T_E]=v_text_m_HB


            ###### SHR1 #####
            v_text_m_SHR=[]
            i=1
            nciclos=int(len(d_r_SHR1[T_E])/2)
            for i in range(1,nciclos+1):
                a="Span " + str(i) + " left end"
                b="Span " + str(i) + " right end"
                v_text_m_SHR.append(a)
                v_text_m_SHR.append(b)

            d_r_text_SHR[T_E]=v_text_m_SHR

            fail_hb=0
            fail_shr=0
            fail=0
            for x in d_r_d_result_HB[T_E]:
                if (d_r_d_result_HB[T_E][x]=='FAIL'):
                    fail=1
                    fail_hb=1
            if fail_hb==1:
                d_current_status_hb[T_E]="FAIL"
            else:
                d_current_status_hb[T_E]="OK"

            for x in d_r_d_result_SHR[T_E]:
                if (d_r_d_result_SHR[T_E][x]=='FAIL'):
                    fail=1
                    fail_shr=1

            if fail_shr==1:
                d_current_status_shr[T_E]="FAIL"
            else:
                d_current_status_shr[T_E]="OK"

            if fail==1:
                d_current_status[T_E]="FAIL"
            else:
                d_current_status[T_E]="OK"
                    
        if(St_type=="2"):  
            d_estructure_Type_convert[T_E]='Box/Frame'   
            
            #####botones#####
            OPTlhfixed=0
            OPTlhpin=1
            OPTrhfixed=0
            OPTrhpin=1        

            Factored=1
            NoOF=0
            NoDF=0
            NoFact=0

            PREPARE_CALCS()
            if(HB_or_SV=="HB"):
                MaxMoveMomHB1,MaxMoveShrHB1=Load_Vehicle_HB_Fact()
            elif(HB_or_SV=='SV'):
                MaxMoveMomHB1,MaxMoveShrHB1=Load_Vehicle_SV_Fact()

            for I in range(1, 26):
                for J in range(1, 7):
                    MaxMoveMomHB11[I, J] = MaxMoveMomHB1[I, J]
            for I in range(1, 26):
                for J in range(1, 6):
                    MaxMoveShrHB11[I, J] = MaxMoveShrHB1[I, J]

            L=np.zeros(11)
            EIStrt=np.zeros(11)
            Lleft=np.zeros(11)
            EI=np.zeros(11)
            KEI=np.zeros((11,3))
            FEM=np.zeros((11,3))
            Vehicle=np.zeros((51,3))
            Loadin=np.zeros((6,101))
            FEM1=np.zeros((11,3))
            FEM2=np.zeros((11,3))
            Rv=np.zeros(12)
            MaxMoveMomHB=np.zeros((26,7))
            MaxMoveMomHB22=np.zeros((26,7))
            
            MaxMoveShrHB=np.zeros((26,6))
            workssheetLB6coma2masI=np.zeros(11)
            MaxMoveMom=np.zeros((43,4))
            MaxMoveShr=np.zeros((26,3))        
            OpeninFlag=0########?????               
            workssheetLB3coma2masI=np.zeros(11)       



            PREPARE_CALCS()
            MaxMoveMomHB2,MaxMoveShrHB2=Load_Axles_AIL()

            for I in range(1, 25 + 1):
                for J in range(1, 7):
                    MaxMoveMomHB22[I, J] = MaxMoveMomHB2[I, J]
            for I in range(1, 25 + 1):
                for J in range(1, 6):
                    MaxMoveShrHB22[I, J] = MaxMoveShrHB2[I, J]
        
            print("*****************PINNED***********************")
            HB1_pin, SHR1_pin, HB2_pin, SHR2_pin, d_result_HB_pin, d_result_SHR_pin = comparative(MaxMoveMomHB11, MaxMoveMomHB22, MaxMoveShrHB11, MaxMoveShrHB22)

            d_r_HB1_pin[T_E]=HB1_pin
            d_r_SHR1_pin[T_E]=SHR1_pin
            d_r_HB2_pin[T_E]=HB2_pin
            d_r_SHR2_pin[T_E]=SHR2_pin
            d_r_d_result_HB_pin[T_E]=d_result_HB_pin
            d_r_d_result_SHR_pin[T_E]=d_result_SHR_pin



            ##################################### RETURN VALUES ########################            
            ######## HB1 ########
            v_text_m_HB=[]
            i=1           
            nciclos=int(len(d_r_HB1_pin[T_E])/2)
            for i in range(1,nciclos+1):
                a="Mom at sup " + str(i)
                b="Mom at span " + str(i)
                v_text_m_HB.append(a)
                v_text_m_HB.append(b)
            c="Mom at sup " + str(i+1)
            v_text_m_HB.append(c)

            d_r_text_HB_pin[T_E]=v_text_m_HB


            ###### SHR1 #####
            v_text_m_SHR=[]
            i=1
            nciclos=int(len(d_r_SHR1_pin[T_E])/2)
            for i in range(1,nciclos+1):
                a="Span " + str(i) + " left end"
                b="Span " + str(i) + " right end"
                v_text_m_SHR.append(a)
                v_text_m_SHR.append(b)

            d_r_text_SHR_pin[T_E]=v_text_m_SHR


            fail=0
            for x in d_r_d_result_HB_pin[T_E]:
                if (d_r_d_result_HB_pin[T_E][x]=='FAIL'):
                    fail=1
            for x in d_r_d_result_SHR_pin[T_E]:
                if (d_r_d_result_SHR_pin[T_E][x]=='FAIL'):
                    fail=1
            if fail==1:
                d_current_status_pin[T_E]="FAIL"
            else:
                d_current_status_pin[T_E]="OK"






            L=np.zeros(11)
            EIStrt=np.zeros(11)
            Lleft=np.zeros(11)
            EI=np.zeros(11)
            KEI=np.zeros((11,3))
            FEM=np.zeros((11,3))
            Vehicle=np.zeros((51,3))
            Loadin=np.zeros((6,101))
            FEM1=np.zeros((11,3))
            FEM2=np.zeros((11,3))
            Rv=np.zeros(12)
            MaxMoveMomHB=np.zeros((26,7))
            MaxMoveMomHB11=np.zeros((26,7))
            MaxMoveMomHB22=np.zeros((26,7))        
            MaxMoveShrHB=np.zeros((26,6))
            workssheetLB6coma2masI=np.zeros(11)
            MaxMoveMom=np.zeros((43,4))
            MaxMoveShr=np.zeros((26,3))
            OpeninFlag=0

            #####botones#####3
            OPTlhfixed=1
            OPTlhpin=0
            OPTrhfixed=1
            OPTrhpin=0
            
            workssheetLB3coma2masI=np.zeros(11)


            PREPARE_CALCS()

            if(HB_or_SV=="HB"):
                MaxMoveMomHB1,MaxMoveShrHB1=Load_Vehicle_HB_Fact()
            elif(HB_or_SV=='SV'):
                MaxMoveMomHB1,MaxMoveShrHB1=Load_Vehicle_SV_Fact()

            for I in range(1, 25 + 1):
                for J in range(1, 7):
                    MaxMoveMomHB11[I, J] = MaxMoveMomHB1[I, J]
            for I in range(1, 25 + 1):
                for J in range(1, 6):
                    MaxMoveShrHB11[I, J] = MaxMoveShrHB1[I, J]

            L=np.zeros(11)
            EIStrt=np.zeros(11)
            Lleft=np.zeros(11)
            EI=np.zeros(11)
            KEI=np.zeros((11,3))
            FEM=np.zeros((11,3))
            Vehicle=np.zeros((51,3))
            Loadin=np.zeros((6,101))
            FEM1=np.zeros((11,3))
            FEM2=np.zeros((11,3))
            Rv=np.zeros(12)
            MaxMoveMomHB=np.zeros((26,7))
            MaxMoveMomHB22=np.zeros((26,7))        
            MaxMoveShrHB=np.zeros((26,6))
            workssheetLB6coma2masI=np.zeros(11)
            MaxMoveMom=np.zeros((43,4))
            MaxMoveShr=np.zeros((26,3))
            OpeninFlag=0            
            workssheetLB3coma2masI=np.zeros(11)


            PREPARE_CALCS()
            MaxMoveMomHB2,MaxMoveShrHB2=Load_Axles_AIL()

            for I in range(1, 25 + 1):
                for J in range(1, 7):
                    MaxMoveMomHB22[I, J] = MaxMoveMomHB2[I, J]
            for I in range(1, 25 + 1):
                for J in range(1, 6):
                    MaxMoveShrHB22[I, J] = MaxMoveShrHB2[I, J]
        
            print("*****************FIXED***********************")
            HB1_fix, SHR1_fix, HB2_fix, SHR2_fix, d_result_HB_fix, d_result_SHR_fix=comparative(MaxMoveMomHB11, MaxMoveMomHB22,MaxMoveShrHB11, MaxMoveShrHB22)

            d_r_HB1_fix[T_E]=HB1_fix
            d_r_SHR1_fix[T_E]=SHR1_fix
            d_r_HB2_fix[T_E]=HB2_fix
            d_r_SHR2_fix[T_E]=SHR2_fix
            d_r_d_result_HB_fix[T_E]=d_result_HB_fix
            d_r_d_result_SHR_fix[T_E]=d_result_SHR_fix

            ##################################### RETURN VALUES ########################            
            ######## HB1 ########
            v_text_m_HB=[]
            i=1           
            nciclos=int(len(d_r_HB1_fix[T_E])/2)
            for i in range(1,nciclos+1):
                a="Mom at sup " + str(i)
                b="Mom at span " + str(i)
                v_text_m_HB.append(a)
                v_text_m_HB.append(b)
            c="Mom at sup " + str(i+1)
            v_text_m_HB.append(c)

            d_r_text_HB_fix[T_E]=v_text_m_HB


            ###### SHR1 #####
            v_text_m_SHR=[]
            i=1
            nciclos=int(len(d_r_SHR1_pin[T_E])/2)
            for i in range(1,nciclos+1):
                a="Span " + str(i) + " left end"
                b="Span " + str(i) + " right end"
                v_text_m_SHR.append(a)
                v_text_m_SHR.append(b)

            d_r_text_SHR_fix[T_E]=v_text_m_SHR


            fail=0
            for x in d_r_d_result_HB_fix[T_E]:
                if (d_r_d_result_HB_fix[T_E][x]=='FAIL'):
                    fail=1

            for x in d_r_d_result_SHR_fix[T_E]:
                if (d_r_d_result_SHR_fix[T_E][x]=='FAIL'):
                    fail=1
            if fail==1:
                d_current_status_fix[T_E]="FAIL"
            else:
                d_current_status_fix[T_E]="OK"




            fail_hb=0
            fail_shr=0
            fail=0
            for x in d_r_d_result_HB_pin[T_E]:
                if (d_r_d_result_HB_pin[T_E][x]=='FAIL'):
                    fail=1
                    fail_hb=1
            for x in d_r_d_result_HB_fix[T_E]:
                if (d_r_d_result_HB_fix[T_E][x]=='FAIL'):
                    fail=1
                    fail_hb=1
            if fail_hb==1:
                d_current_status_hb[T_E]="FAIL"
            else:
                d_current_status_hb[T_E]="OK"

            for x in d_r_d_result_SHR_pin[T_E]:
                if (d_r_d_result_SHR_pin[T_E][x]=='FAIL'):
                    fail=1
                    fail_shr=1
            for x in d_r_d_result_SHR_fix[T_E]:
                if (d_r_d_result_SHR_fix[T_E][x]=='FAIL'):
                    fail=1
                    fail_shr=1
            if fail_shr==1:
                d_current_status_shr[T_E]="FAIL"
            else:
                d_current_status_shr[T_E]="OK"

            if (fail_hb==1 or fail_shr==1):
                d_current_status[T_E]='FAIL'
            else:
                d_current_status[T_E]='OK'

        if(St_type=="3"):     
            d_estructure_Type_convert[T_E]='Simply-Supported'
            Simply_Supported=1

            L=np.zeros(11)
            EIStrt=np.zeros(11)
            Lleft=np.zeros(11)
            EI=np.zeros(11)
            KEI=np.zeros((11,3))
            FEM=np.zeros((11,3))
            Vehicle=np.zeros((51,3))
            Loadin=np.zeros((6,101))
            FEM1=np.zeros((11,3))
            FEM2=np.zeros((11,3))
            Rv=np.zeros(12)
            MaxMoveMomHB=np.zeros((26,7))
            MaxMoveMomHB11=np.zeros((26,7))
            MaxMoveMomHB22=np.zeros((26,7))        
            MaxMoveShrHB=np.zeros((26,6))
            workssheetLB6coma2masI=np.zeros(11)
            MaxMoveMom=np.zeros((43,4))
            MaxMoveShr=np.zeros((26,3))
            OpeninFlag=0
            #####botones#####
            OPTlhfixed=0
            OPTlhpin=1
            OPTrhfixed=0
            OPTrhpin=1
            #################        
            workssheetLB3coma2masI=np.zeros(11)

            PREPARE_CALCS()
            v_HB1, v_SHR1, v_HB2, v_SHR2, v_d_result_HB, v_d_result_SHR=CALC_SS_HB_AIL() 

            d_r_HB1[T_E]=v_HB1
            d_r_SHR1[T_E]=v_SHR1
            d_r_HB2[T_E]=v_HB2
            d_r_SHR2[T_E]=v_SHR2
            d_r_d_result_HB[T_E]=v_d_result_HB
            d_r_d_result_SHR[T_E]=v_d_result_SHR   

            
            fail=0
            fail_hb=0
            fail_shr=0
            for x in range(0,len(d_r_d_result_HB[T_E])):
                for xx in range(0,len(d_r_d_result_HB[T_E][x])):
                    if (d_r_d_result_HB[T_E][x][xx]=='FAIL'):
                        fail=1
                        fail_hb=1
            if fail_hb==1:
                d_current_status_hb[T_E]="FAIL"
            else:
                d_current_status_hb[T_E]="OK"

            for x in range(0,len(d_r_d_result_SHR[T_E])):
                for xx in range(0,len(d_r_d_result_SHR[T_E][x])):
                    if (d_r_d_result_SHR[T_E][x][xx]=='FAIL'):
                        fail=1
                        fail_shr=1
            if fail_shr==1:
                d_current_status_shr[T_E]="FAIL"
            else:
                d_current_status_shr[T_E]="OK"
            if fail==1:
                d_current_status[T_E]="FAIL"
            else:
                d_current_status[T_E]="OK"


            #print(d_current_status_shr[T_E])
            #print(d_r_d_result_SHR[T_E])


            #################################  RETURN  VALUES  ########################
            

            ###### HB1 #####
            v_text_m_HB=[]
            i=1

            for y in range(0,len(d_r_HB1[T_E])):  
                nciclos=int(len(d_r_HB1[T_E][y])/2)
                for i in range(1,nciclos+1):
                    a="Mom at sup " + str(y+1)
                    b="Mom at span " + str(y+1)
                    v_text_m_HB.append(a)
                    v_text_m_HB.append(b)
                c="Mom at sup " + str(y+1+1)
                v_text_m_HB.append(c)
                d_r_text_m_HB[y]=v_text_m_HB
                v_text_m_HB=[]

            d_r_text_HB[T_E]=d_r_text_m_HB
            d_r_text_m_HB={}

            ###### SHR1 #####

            v_text_m_SHR=[]
            i=1
            for y in range(0,len(d_r_SHR1[T_E])):             
                nciclos=int(len(d_r_SHR1[T_E][y])/2)
                for i in range(1,nciclos+1):
                    a="Span " + str(y+1) + " left end"
                    b="Span " + str(y+1) + " right end"
                    v_text_m_SHR.append(a)
                    v_text_m_SHR.append(b)
                d_r_text_m_SHR[y]=v_text_m_SHR
                v_text_m_SHR=[]

            d_r_text_SHR[T_E]=d_r_text_m_SHR
            d_r_text_m_SHR={}

        if(St_type=="4"):
            d_estructure_Type_convert[T_E]='Half-Joint'

            OPTlhfixed=0
            OPTlhpin=1
            OPTrhfixed=0
            OPTrhpin=1 

            PREPARE_CALCS()
            if(HB_or_SV=="HB"):
                MaxMoveMomHB1,MaxMoveShrHB1=Load_Vehicle_HB_Fact()
            elif(HB_or_SV=='SV'):
                MaxMoveMomHB1,MaxMoveShrHB1=Load_Vehicle_SV_Fact()

            for I in range(1, 26):
                for J in range(1, 7):
                    MaxMoveMomHB11[I, J] = MaxMoveMomHB1[I, J]

            for I in range(1, 26):
                for J in range(1, 6):
                    MaxMoveShrHB11[I, J] = MaxMoveShrHB1[I, J]

            L=np.zeros(11)
            EIStrt=np.zeros(11)
            Lleft=np.zeros(11)
            EI=np.zeros(11)
            KEI=np.zeros((11,3))
            FEM=np.zeros((11,3))
            Vehicle=np.zeros((51,3))
            Loadin=np.zeros((6,101))
            FEM1=np.zeros((11,3))
            FEM2=np.zeros((11,3))
            Rv=np.zeros(12)
            MaxMoveMomHB=np.zeros((26,7))
            
            MaxMoveShrHB=np.zeros((26,6))
            workssheetLB6coma2masI=np.zeros(11)
            MaxMoveMom=np.zeros((43,4))
            MaxMoveShr=np.zeros((26,3))
            OpeninFlag=0########?????        
            workssheetLB3coma2masI=np.zeros(11)

            PREPARE_CALCS()
            MaxMoveMomHB2, MaxMoveShrHB2=Load_Axles_AIL()

            for I in range(1, 26):
                for J in range(1, 7):
                    MaxMoveMomHB22[I, J] = MaxMoveMomHB2[I, J]

            for I in range(1, 26):
                for J in range(1, 6):
                    MaxMoveShrHB22[I, J] = MaxMoveShrHB2[I, J]


            HB1, SHR1, HB2, SHR2, d_result_HB, d_result_SHR = comparative(MaxMoveMomHB11, MaxMoveMomHB22,MaxMoveShrHB11,MaxMoveShrHB22)

            d_r_HB1[T_E]=HB1
            d_r_SHR1[T_E]=SHR1
            d_r_HB2[T_E]=HB2
            d_r_SHR2[T_E]=SHR2
            d_r_d_result_HB[T_E]=d_result_HB
            d_r_d_result_SHR[T_E]=d_result_SHR


            ##################################### RETURN VALUES ########################            
            ######## HB1 ########
            v_text_m_HB=[]
            i=1           
            nciclos=int(len(d_r_HB1[T_E])/2)
            for i in range(1,nciclos+1):
                a="Mom at sup " + str(i)
                b="Mom at span " + str(i)
                v_text_m_HB.append(a)
                v_text_m_HB.append(b)
            c="Mom at sup " + str(i+1)
            v_text_m_HB.append(c)

            d_r_text_HB[T_E]=v_text_m_HB


            ###### SHR1 #####
            v_text_m_SHR=[]
            i=1
            nciclos=int(len(d_r_SHR1[T_E])/2)
            for i in range(1,nciclos+1):
                a="Span " + str(i) + " left end"
                b="Span " + str(i) + " right end"
                v_text_m_SHR.append(a)
                v_text_m_SHR.append(b)

            d_r_text_SHR[T_E]=v_text_m_SHR
            ##################################### END RETURN VALUES ######################## 




            ##IF COUNTINOUS WORKS##    DO JUST ONE SIMPLY SUPPORTED

            fail=0
            fail_hb=0
            fail_shr=0
            fallaContinouos=0
            for x in d_r_d_result_HB[T_E]:
                if (d_r_d_result_HB[T_E][x]=='FAIL'):
                    fail=1
                    fail_hb=1
            for x in d_r_d_result_SHR[T_E]:
                if (d_r_d_result_SHR[T_E][x]=='FAIL'):
                    fail=1
                    fail_shr=1


            if fail_hb==1:
                d_current_status_hb[T_E]='FAIL'
            else:
                d_current_status_hb[T_E]='OK'

            if fail_shr==1:
                d_current_status_shr[T_E]='FAIL'
            else:
                d_current_status_shr[T_E]='OK'

            if (fail==0):
                d_fallaContinouos[T_E]='OK'
                HB1_hjs, SHR1_hjs, HB2_hjs, SHR2_hjs, d_result_HB_hjs, d_result_SHR_hjs,Result_HJ_hjs, Vcant1, Vcant2, Mcant1, Mcant2=HalfJointedSpan(HB_or_SV)
                v_extra_check_hj=np.zeros((1,4))
                v_extra_check_hj[0][0]=round(Vcant1,1)
                v_extra_check_hj[0][1]=round(Vcant2,1)
                v_extra_check_hj[0][2]=round(Mcant1,1)
                v_extra_check_hj[0][3]=round(Mcant2,1)
                d_extra_check_hj[T_E]=v_extra_check_hj

            else:
                fallaContinouos=1
                d_fallaContinouos[T_E]='FAIL'

    
            if (fail==0 and valid_data==1):
                d_r_HB1_hjs[T_E]=HB1_hjs
                d_r_SHR1_hjs[T_E]=SHR1_hjs 
                d_r_HB2_hjs[T_E]=HB2_hjs
                d_r_SHR2_hjs[T_E]=SHR2_hjs
                d_r_d_result_HB_hjs[T_E]=d_result_HB_hjs
                d_r_d_result_SHR_hjs[T_E]=d_result_SHR_hjs
                d_r_Result_HJ_hjs[T_E]=Result_HJ_hjs

                ##################################### RETURN VALUES ########################            
                ######## HB1 ########
                v_text_m_HB=[]
                i=1           
                nciclos=int(len(d_r_HB1_hjs[T_E])/2)
                for i in range(1,nciclos+1):
                    a="Mom at sup " + str(i)
                    b="Mom at span " + str(i)
                    v_text_m_HB.append(a)
                    v_text_m_HB.append(b)
                c="Mom at sup " + str(i+1)
                v_text_m_HB.append(c)

                d_r_text_HB_hjs[T_E]=v_text_m_HB


                ###### SHR1 #####
                v_text_m_SHR=[]
                i=1
                nciclos=int(len(d_r_SHR1[T_E])/2)
                for i in range(1,2):
                    a="Span " + str(i) + " left end"
                    b="Span " + str(i) + " right end"
                    v_text_m_SHR.append(a)
                    v_text_m_SHR.append(b)

                d_r_text_SHR_hjs[T_E]=v_text_m_SHR
                

                #### if ok o fail
                fail_hjs=0
                fail_hb_hjs=0
                fail_shr_hjs=0
                for x in d_r_d_result_HB_hjs[T_E]:
                    if (d_r_d_result_HB_hjs[T_E][x]=='FAIL'):
                        fail_hjs=1
                        fail_hb_hjs=1
                for x in d_r_d_result_SHR_hjs[T_E]:
                    if (d_r_d_result_SHR_hjs[T_E][x]=='FAIL'):
                        fail_hjs=1
                        fail_shr_hjs=1
                if fail_hjs==1:
                    d_current_status[T_E]="FAIL"
                else:
                    d_current_status[T_E]="OK"


                if fail_hb_hjs==1:
                    d_current_status_hb_hjs[T_E]='FAIL'
                else:
                    d_current_status_hb_hjs[T_E]='OK'
                if fail_shr_hjs==1 :
                    d_current_status_shr_hjs[T_E]='FAIL'
                else:
                    d_current_status_shr_hjs[T_E]='OK'

                if Result_HJ_hjs=='FAIL':
                    d_current_status[T_E]="FAIL"

            else:
                d_current_status[T_E]="FAIL"







        global d_current_status_localRecalculate
        global d_HB_or_SV_localRecalculate
        global d_HB_or_SV_value_localRecalculate
        global d_r_St_type_localRecalculate
        global d_r_HB1_localRecalculate
        global d_r_text_HB_localRecalculate
        global d_r_HB2_localRecalculate
        global d_r_d_result_HB_localRecalculate
        global d_r_SHR1_localRecalculate
        global d_r_text_SHR_localRecalculate
        global d_r_SHR2_localRecalculate
        global d_r_d_result_SHR_localRecalculate
        global d_r_text_HB_pin_localRecalculate
        global d_r_text_SHR_pin_localRecalculate
        global d_r_HB1_pin_localRecalculate
        global d_r_SHR1_pin_localRecalculate
        global d_r_HB2_pin_localRecalculate
        global d_r_SHR2_pin_localRecalculate
        global d_r_d_result_HB_pin_localRecalculate
        global d_r_d_result_SHR_pin_localRecalculate
        global d_r_text_HB_fix_localRecalculate
        global d_r_text_SHR_fix_localRecalculate 
        global d_r_HB1_fix_localRecalculate 
        global d_r_SHR1_fix_localRecalculate 
        global d_r_HB2_fix_localRecalculate
        global d_r_SHR2_fix_localRecalculate 
        global d_r_d_result_HB_fix_localRecalculate 
        global d_r_d_result_SHR_fix_localRecalculate 
        global d_fallaContinouos_localRecalculate
        global d_r_HB1_hjs_localRecalculate 
        global d_r_SHR1_hjs_localRecalculate 
        global d_r_HB2_hjs_localRecalculate 
        global d_r_SHR2_hjs_localRecalculate 
        global d_r_d_result_HB_hjs_localRecalculate
        global d_r_d_result_SHR_hjs_localRecalculate 
        global d_r_Result_HJ_hjs_localRecalculate 
        global d_r_text_HB_hjs_localRecalculate 
        global d_r_text_SHR_hjs_localRecalculate
        global d_current_status_hb_localRecalculate 
        global d_current_status_shr_localRecalculate 
        global d_sf_localRecalculate 
        global d_Span_SVRating_localRecalculate
        global d_estructure_Type_convert_localRecalculate 
        global d_current_status_hb_hjs_localRecalculate 
        global d_current_status_shr_hjs_localRecalculate
        global d_ldds_f_localRecalculate 
        global d_ldds_position_f_localRecalculate 
        global valid_data_localRecalculate 
        global d_extra_check_hj_localRecalculate



        d_current_status_localRecalculate={}
        d_current_status_localRecalculate=d_current_status
        d_HB_or_SV_localRecalculate={}
        d_HB_or_SV_localRecalculate=d_HB_or_SV
        d_HB_or_SV_value_localRecalculate={}
        d_HB_or_SV_value_localRecalculate=d_HB_or_SV_value
        d_r_St_type_localRecalculate={}
        d_r_St_type_localRecalculate=d_r_St_type
        d_r_HB1_localRecalculate={}
        d_r_HB1_localRecalculate=d_r_HB1
        d_r_text_HB_localRecalculate={}
        d_r_text_HB_localRecalculate=d_r_text_HB
        d_r_HB2_localRecalculate={}
        d_r_HB2_localRecalculate=d_r_HB2
        d_r_d_result_HB_localRecalculate={}
        d_r_d_result_HB_localRecalculate=d_r_d_result_HB
        d_r_SHR1_localRecalculate={}
        d_r_SHR1_localRecalculate=d_r_SHR1
        d_r_text_SHR_localRecalculate={}
        d_r_text_SHR_localRecalculate=d_r_text_SHR
        d_r_SHR2_localRecalculate={}
        d_r_SHR2_localRecalculate=d_r_SHR2
        d_r_d_result_SHR_localRecalculate={}
        d_r_d_result_SHR_localRecalculate=d_r_d_result_SHR
        d_r_text_HB_pin_localRecalculate={}
        d_r_text_HB_pin_localRecalculate=d_r_text_HB_pin
        d_r_text_SHR_pin_localRecalculate={}
        d_r_text_SHR_pin_localRecalculate=d_r_text_SHR_pin
        d_r_HB1_pin_localRecalculate={}
        d_r_HB1_pin_localRecalculate=d_r_HB1_pin

        d_r_SHR1_pin_localRecalculate={}
        d_r_SHR1_pin_localRecalculate=d_r_SHR1_pin
        d_r_HB2_pin_localRecalculate={}
        d_r_HB2_pin_localRecalculate=d_r_HB2_pin
        d_r_SHR2_pin_localRecalculate={}
        d_r_SHR2_pin_localRecalculate=d_r_SHR2_pin
        d_r_d_result_HB_pin_localRecalculate={}
        d_r_d_result_HB_pin_localRecalculate=d_r_d_result_HB_pin
        d_r_d_result_SHR_pin_localRecalculate={}
        d_r_d_result_SHR_pin_localRecalculate=d_r_d_result_SHR_pin
        d_r_text_HB_fix_localRecalculate={}
        d_r_text_HB_fix_localRecalculate=d_r_text_HB_fix
        d_r_text_SHR_fix_localRecalculate={}
        d_r_text_SHR_fix_localRecalculate=d_r_text_SHR_fix
        d_r_HB1_fix_localRecalculate={}
        d_r_HB1_fix_localRecalculate=d_r_HB1_fix
        d_r_SHR1_fix_localRecalculate={}
        d_r_SHR1_fix_localRecalculate=d_r_SHR1_fix
        d_r_HB2_fix_localRecalculate={}
        d_r_HB2_fix_localRecalculate=d_r_HB2_fix
        d_r_SHR2_fix_localRecalculate={}
        d_r_SHR2_fix_localRecalculate=d_r_SHR2_fix
        d_r_d_result_HB_fix_localRecalculate={}
        d_r_d_result_HB_fix_localRecalculate=d_r_d_result_HB_fix
        d_r_d_result_SHR_fix_localRecalculate={}
        d_r_d_result_SHR_fix_localRecalculate=d_r_d_result_SHR_fix
        d_fallaContinouos_localRecalculate={}
        d_fallaContinouos_localRecalculate=d_fallaContinouos
        d_r_HB1_hjs_localRecalculate={}
        d_r_HB1_hjs_localRecalculate=d_r_HB1_hjs
        d_r_SHR1_hjs_localRecalculate={}
        d_r_SHR1_hjs_localRecalculate=d_r_SHR1_hjs
        d_r_HB2_hjs_localRecalculate={}
        d_r_HB2_hjs_localRecalculate=d_r_HB2_hjs
        d_r_SHR2_hjs_localRecalculate={}
        d_r_SHR2_hjs_localRecalculate=d_r_SHR2_hjs
        d_r_d_result_HB_hjs_localRecalculate={}
        d_r_d_result_HB_hjs_localRecalculate=d_r_d_result_HB_hjs
        d_r_d_result_SHR_hjs_localRecalculate={}
        d_r_d_result_SHR_hjs_localRecalculate=d_r_d_result_SHR_hjs
        d_r_Result_HJ_hjs_localRecalculate={}
        d_r_Result_HJ_hjs_localRecalculate=d_r_Result_HJ_hjs
        d_r_text_HB_hjs_localRecalculate={}
        d_r_text_HB_hjs_localRecalculate=d_r_text_HB_hjs
        d_r_text_SHR_hjs_localRecalculate={}
        d_r_text_SHR_hjs_localRecalculate=d_r_text_SHR_hjs
        d_current_status_hb_localRecalculate={}
        d_current_status_hb_localRecalculate=d_current_status_hb
        d_current_status_shr_localRecalculate={}
        d_current_status_shr_localRecalculate=d_current_status_shr
        d_sf_localRecalculate={}
        d_sf_localRecalculate=d_sf
        d_Span_SVRating_localRecalculate={}
        d_Span_SVRating_localRecalculate=d_Span_SVRating
        d_estructure_Type_convert_localRecalculate={}
        d_estructure_Type_convert_localRecalculate=d_estructure_Type_convert
        d_current_status_hb_hjs_localRecalculate={}
        d_current_status_hb_hjs_localRecalculate=d_current_status_hb_hjs
        d_current_status_shr_hjs_localRecalculate={}
        d_current_status_shr_hjs_localRecalculate=d_current_status_shr_hjs
        d_ldds_f_localRecalculate={}
        d_ldds_f_localRecalculate=d_ldds_f
        d_ldds_position_f_localRecalculate={}
        d_ldds_position_f_localRecalculate=d_ldds_position_f
        valid_data_localRecalculate={}
        valid_data_localRecalculate=valid_data
        d_extra_check_hj_localRecalculate={}
        d_extra_check_hj_localRecalculate=d_extra_check_hj




        return render(request, 'result_modified.html',{'structure':structure, 'd_StructureKey':d_StructureKey, 'd_current_status':d_current_status ,'d_HB_or_SV':d_HB_or_SV, 'd_HB_or_SV_value':d_HB_or_SV_value,  'notice_reference':notice_reference,'d_r_St_type':d_r_St_type, 'd_r_HB1':d_r_HB1, 'd_r_text_HB':d_r_text_HB,\
        'd_r_HB2':d_r_HB2, 'd_r_d_result_HB':d_r_d_result_HB,'d_r_SHR1':d_r_SHR1 ,'d_r_text_SHR':d_r_text_SHR, 'd_r_SHR2':d_r_SHR2, 'd_r_d_result_SHR':d_r_d_result_SHR,\
        'vehicle_assessed':vehicle_assessed, 'd_r_text_HB_pin':d_r_text_HB_pin,'d_r_text_SHR_pin': d_r_text_SHR_pin, 'd_r_HB1_pin':d_r_HB1_pin,'d_r_SHR1_pin':d_r_SHR1_pin,\
        'd_r_HB2_pin':d_r_HB2_pin, 'd_r_SHR2_pin':d_r_SHR2_pin, 'd_r_d_result_HB_pin': d_r_d_result_HB_pin,'d_r_d_result_SHR_pin': d_r_d_result_SHR_pin,\
        'd_r_text_HB_fix':d_r_text_HB_fix,'d_r_text_SHR_fix': d_r_text_SHR_fix, 'd_r_HB1_fix':d_r_HB1_fix,'d_r_SHR1_fix':d_r_SHR1_fix, 'd_r_HB2_fix':d_r_HB2_fix,\
        'd_r_SHR2_fix':d_r_SHR2_fix, 'd_r_d_result_HB_fix': d_r_d_result_HB_fix, 'd_r_d_result_SHR_fix': d_r_d_result_SHR_fix, 'd_fallaContinouos':d_fallaContinouos,\
        'd_r_HB1_hjs':d_r_HB1_hjs, 'd_r_SHR1_hjs':d_r_SHR1_hjs, 'd_r_HB2_hjs':d_r_HB2_hjs, 'd_r_SHR2_hjs':d_r_SHR2_hjs, 'd_r_d_result_HB_hjs':d_r_d_result_HB_hjs,\
        'd_r_d_result_SHR_hjs':d_r_d_result_SHR_hjs, 'd_r_Result_HJ_hjs':d_r_Result_HJ_hjs, 'd_r_text_HB_hjs': d_r_text_HB_hjs, 'd_r_text_SHR_hjs':d_r_text_SHR_hjs,\
        'd_current_status_hb':d_current_status_hb, 'd_current_status_shr':d_current_status_shr, 'd_sf':d_sf, 'd_Span_SVRating':d_Span_SVRating,\
        'd_estructure_Type_convert':d_estructure_Type_convert, 'd_current_status_hb_hjs': d_current_status_hb_hjs, 'd_current_status_shr_hjs':d_current_status_shr_hjs,\
        'd_ldds_f':d_ldds_f, 'd_ldds_position_f':d_ldds_position_f, 'valid_data':valid_data, 'd_extra_check_hj':d_extra_check_hj})

def databaseSimulate(StructureKey):
    global databaseHJ

    ishalfjoint=0
    Ldds_f=0
    Ldds_position_f=0

    for x in range(0,len(databaseHJ)):
        if databaseHJ[x][0]==StructureKey:
            Ldds_f=databaseHJ[x][1]
            Ldds_position_f=databaseHJ[x][2]
            ishalfjoint=1
    return ishalfjoint,Ldds_f,Ldds_position_f

def home(request):
    next = request.GET.get('next')
    form = UserLoginForm(request.POST or None)
    if form.is_valid():
        username = form.cleaned_data.get('username')
        password = form.cleaned_data.get('password')
        user = authenticate(username=username, password=password)
        login(request, user)
        if next:
            return redirect(next)
        return redirect('/')

    context = {
        'form': form,
    }
    return render(request, 'home.html',context)

def login_view(request):

    username = request.POST['username']
    password = request.POST['password']
    user = authenticate(request, username=username, password=password)
    
    if user is not None:
        login(request, user)
        #logout(request)
        return render(request, 'jsontochoose.html')
    else:
        return render(request, 'home.html')

    


def globalvariables():
    global OpeninFlag
    
    global L
    # global workssheetLB10masIcoma22
    # global workssheetLB10masIcoma24    
    # global SV_Rating
    # global Reserve_Factor
    # global HB_rating
    global sf
    global EIStrt
    global Lleft
    global KEI
    global EI
    global FEM
    global Vehicle
    global Loadin
    global FEM1
    global FEM2
    global Rv
    global MaxMoveMomHB
    global MaxMoveMomHB11
    global MaxMoveMomHB22
    global MaxMoveShrHB
    global MaxMoveShrHB11
    global MaxMoveShrHB22
    global workssheetLB6coma2masI
    global MaxMoveMom
    global MaxMoveShr
    
    global workssheetLB3coma2masI
    global Factored
    global NoOF
    global NoDF
    global NoFact



    #workssheetLB10masIcoma22 = [0,121,122,123,124,125,126,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    #workssheetLB10masIcoma24 = [0,3,4,5,6,7,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    #workssheetLB4coma2masI   = [0,10,15,10,0,0,0,0,0,0,0]
    #workssheetLB5coma2masI   = [0,1,1,1,0,0,0,0,0,0,0]
    #SV_Rating="SV150" 
    #Reserve_Factor = 1.2    
    #HB_rating=25


    sf=0.95



    L=np.zeros(11)
    EIStrt=np.zeros(11)
    Lleft=np.zeros(11)

    EI=np.zeros(11)
    KEI=np.zeros((11,3))
    FEM=np.zeros((11,3))
    Vehicle=np.zeros((51,3))
    Loadin=np.zeros((6,101))
    FEM1=np.zeros((11,3))
    FEM2=np.zeros((11,3))
    Rv=np.zeros(12)

    MaxMoveMomHB=np.zeros((26,7))
    MaxMoveMomHB11=np.zeros((26,7))
    MaxMoveMomHB22=np.zeros((26,7))
            
    MaxMoveShrHB=np.zeros((26,6))
    MaxMoveShrHB11=np.zeros((26,6))
    MaxMoveShrHB22=np.zeros((26,6))

    workssheetLB6coma2masI=np.zeros(11)
    MaxMoveMom=np.zeros((43,4))
    MaxMoveShr=np.zeros((26,3))
         
        
    OpeninFlag=0
    workssheetLB3coma2masI=np.zeros(11)



    Factored=1
    NoOF=0
    NoDF=0
    NoFact=0

        #####botones#####323754

def Load_Axles_AIL():
    global Factored
    global NoOF
    global NoDF
    global NoFact

    global AXles
    global workssheetLB10masIcoma22
    global workssheetLB10masIcoma24
    global incTee

    global MaxMoveMomHB
    global MaxMoveShrHB


    AXles = 0
    VehicleL = 0
    AxleCount = 1
    incTee = 0
    
    #Worksheets("line beam").Cells(11, 26).Value = AXles
    workssheetLB11coma26= AXles
    
    #'AXles = Worksheets("Line Beam").Range("V11:V40").Cells.SpecialCells(xlCellTypeConstants).Count

    for I in range(1, 30+1):
        #if Worksheets("Line Beam").Cells(10 + I, 22).Value <> 0 Then
        if (workssheetLB10masIcoma22[I]!=0):
            AXles=AXles+1


    #Worksheets("line beam").Cells(11, 25).Value = AXles
    workssheetLB11coma25=AXles
    
     
    for I in range(1, AXles+1):
        #if Worksheets("Line Beam").OptionButtons("Factored").Value = xlOn Then
        if(Factored==1):
            OF = 1.1
            #AxTon = Worksheets("Line Beam").Cells(10 + I, 22).Value / 10
            AxTon = workssheetLB10masIcoma22[I]/10
            DF = 1.7 / AxTon ** 0.15
        #If Worksheets("Line Beam").OptionButtons("NoOF").Value = xlOn Then
        if (NoOF==1):
            OF = 1
            #AxTon = Worksheets("Line Beam").Cells(10 + I, 22).Value / 10
            AxTon = workssheetLB10masIcoma22[I]/10
            DF = 1.7 / AxTon ** 0.15
        #If Worksheets("Line Beam").OptionButtons("NoDF").Value = xlOn Then
        if (NoDF==1):
            OF = 1.1
            DF = 1
        #If Worksheets("Line Beam").OptionButtons("NoFact").Value = xlOn Then
        if (NoFact==1):
            OF = 1
            DF = 1

        #VehicleL = VehicleL + Worksheets("Line Beam").Cells(10 + I, 24).Value
        VehicleL = VehicleL + workssheetLB10masIcoma24[I]
        Colmn = int((I - 1) / 10)
        
        #Vehicle[I, 1] = Worksheets("Line Beam").Cells(10 + I, 22).Value  #'* OF * DF 'OVERLOAD & DINAMIC FACTOR
        Vehicle[I, 1] = workssheetLB10masIcoma22[I]
        Vehicle[I, 2] = VehicleL
        

        ################REVISAR########################
        #Worksheets("Line Beam").Cells(LineC + 2 * (I - 10 * Colmn) - 1, 1 + 4 * Colmn).HorizontalAlignment = xlRight
        #Worksheets("line beam").Cells(LineC + 2 * (I - 10 * Colmn) - 1, 1 + 4 * Colmn) = "W" & I
        #Worksheets("Line Beam").Cells(LineC + 2 * (I - 10 * Colmn) - 1, 2 + 4 * Colmn).HorizontalAlignment = xlCenter
        #Worksheets("line beam").Cells(LineC + 2 * (I - 10 * Colmn) - 1, 2 + 4 * Colmn) = Vehicle(I, 1)
        #Worksheets("Line Beam").Cells(LineC + 2 * (I - 10 * Colmn), 3 + 4 * Colmn).HorizontalAlignment = xlCenter
        #Worksheets("line beam").Cells(LineC + 2 * (I - 10 * Colmn), 3 + 4 * Colmn) = Worksheets("Line Beam").Cells(10 + I, 24).Value
        Vehicle[I, 1] = Vehicle[I, 1] * OF * DF #'OVERLOAD & DINAMIC FACTOR
     

    #Worksheets("line beam").Cells(12, 26).Value = VehicleL
    workssheetLB12coma26 = VehicleL
    # if (AXles > 10.1):
    #     Worksheets("Line Beam").Cells(LineC, 16).HorizontalAlignment = xlRight
    #     Worksheets("Line Beam").Cells(LineC, 16) = "Axle Load  "
    #     Worksheets("Line Beam").Cells(LineC, 17).HorizontalAlignment = xlLeft
    #     Worksheets("Line Beam").Cells(LineC, 17) = "  Axle Spacing"
    # if (AXles > 20.1):
    #     Worksheets("Line Beam").Cells(LineC, 20).HorizontalAlignment = xlRight
    #     Worksheets("Line Beam").Cells(LineC, 20) = "Axle Load  "
    #     Worksheets("Line Beam").Cells(LineC, 21).HorizontalAlignment = xlLeft
    #     Worksheets("Line Beam").Cells(LineC, 21) = "  Axle Spacing"

    Load_Vehicle_AIL_Fact()
    
    return MaxMoveMomHB,MaxMoveShrHB

def Load_Vehicle_AIL_Fact():
    global MaxMoveMomHB
    global MaxMoveShrHB
    global MaxMoveMom
    global MaxMoveShr
    global LorryTimes
    global LorryTimesF
    
    #Dim GammaF As Single, Iimpct As Integer, VehRef As Integer, VehNef(1 To 22) As Integer, VehNcount As Integer, VehStrign As String, Inn As Integer, InnNo As Integer, RowVehNcount As Integer
    
    
    for I in range (1, (2 * (NoSpn * 2 + 1)) + 1):
        for J in range(1, 3 + 1):
            MaxMoveMomHB[I, J] = 0

    for I in range(1, (2 * NoSpn) + 1):
        for J in range(1, 2 + 1):
            MaxMoveShrHB[I, J] = 0

    #If Worksheets("Line Beam").OptionButtons("NoOF").Value = xlOn Or Worksheets("Line Beam").OptionButtons("Factored").Value = xlOn Then
    if (NoOF==1 or Factored==1):
        LorryTimes = AXles   #' Sets number of times the progress lorry crosses the deck
        LorryTimesF = 1
        ImpctFctr = 1.2 / 1.1

        for Iimpct in range(1, AXles+1):  # 'Apply 1.2 Overload factor to each wheel in turn
            if (Iimpct == 1):
                Vehicle[1, 1] = Vehicle[1, 1] * ImpctFctr
            else:
                Vehicle[Iimpct, 1] = Vehicle[Iimpct, 1] * ImpctFctr
                Vehicle[Iimpct - 1, 1] = Vehicle[Iimpct - 1, 1] / ImpctFctr

            MovinVehicle()

            for I in range(1, (2 * NoSpn + 1) + 1, 2):
                if (MaxMoveMom[I, 1] > MaxMoveMomHB[I, 1]):
                    MaxMoveMomHB[I, 1] = MaxMoveMom[I, 1]   #'Moment                 Max hog
                    MaxMoveMomHB[I, 2] = MaxMoveMom[I, 2]   #'Position of Max moment
                    MaxMoveMomHB[I, 3] = MaxMoveMom[I, 3]   #'First wheel position
                    #'MaxMoveMomHB(I, 4) = inrAxle              'Vehicle configuration****************************************************************************
                    if (ImpctFctr > 1.01):
                        MaxMoveMomHB[I, 5] = Iimpct   #'Record which axle has overload factor
                        MaxMoveMomHB[I, 6] = Vehicle[Iimpct, 1]  #'Nominal Axle Load
                if (abs(MaxMoveShr[I, 1]) > abs(MaxMoveShrHB[I, 1])):
                    MaxMoveShrHB[I, 1] = MaxMoveShr[I, 1]   #'Shear                 LHE
                    MaxMoveShrHB[I, 2] = MaxMoveShr[I, 2]   #'First wheel position
                    #'MaxMoveShrHB(I, 3) = inrAxle               'Vehicle configuration
                    if (ImpctFctr > 1.01):
                        MaxMoveShrHB[I, 4] = Iimpct   #'Record which axle has overload factor
                        MaxMoveShrHB[I, 5] = Vehicle[Iimpct, 1] # 'Nominal Axle Load

            for I in range(2, (2 * NoSpn) + 1, 2):
                if (MaxMoveMom[I, 1] < MaxMoveMomHB[I, 1]):
                    MaxMoveMomHB[I, 1] = MaxMoveMom[I, 1] #  'Moment                 Max sag
                    MaxMoveMomHB[I, 2] = MaxMoveMom[I, 2] #  'Position of Max moment
                    MaxMoveMomHB[I, 3] = MaxMoveMom[I, 3] #  'First wheel position
                    #'MaxMoveMomHB(I, 4) = inrAxle             'Vehicle configuration
                    if (ImpctFctr > 1.01):
                        MaxMoveMomHB[I, 5] = Iimpct   #'Record which axle has overload factor
                        MaxMoveMomHB[I, 6] = Vehicle[Iimpct, 1] #  'Nominal Axle Load
                if (abs(MaxMoveShr[I, 1]) > abs(MaxMoveShrHB[I, 1])):
                    MaxMoveShrHB[I, 1] = MaxMoveShr[I, 1] #  'Shear                 RHE
                    MaxMoveShrHB[I, 2] = MaxMoveShr[I, 2] #  'First wheel position
                    #'MaxMoveShrHB(I, 3) = inrAxle                 'Vehicle configuration
                    if (ImpctFctr > 1.01):
                        MaxMoveShrHB[I, 4] = Iimpct   #'Record which axle has overload factor
                        MaxMoveShrHB[I, 5] = Vehicle[Iimpct, 1] # 'Nominal Axle Load          

        Vehicle[AXles, 1] = Vehicle[AXles, 1] / ImpctFctr     #'reset last axle

    else:
        LorryTimes = AXles   #' Sets number of times the progress lorry crosses the deck
        LorryTimesF = 1

        MovinVehicle()

        for I in range(1, (2 * NoSpn + 1) + 1):
            MaxMoveMomHB[I, 1] = MaxMoveMom[I, 1]
            MaxMoveShrHB[I, 1] = MaxMoveShr[I, 1]

    GammaF = 1.1
    for I in range(1, (2 * NoSpn + 1) + 1):
        MaxMoveMomHB[I, 1] = GammaF * MaxMoveMomHB[I, 1]
        MaxMoveShrHB[I, 1] = GammaF * MaxMoveShrHB[I, 1]


    LineC=11
    lineR=AXles
    
def Load_Vehicle_SV_Fact():
    #Dim inrAxle As Single, GammaF As Single, SV_Rating As String, Reserve_Factor As Single, Iimpct As Integer, VehRef As Integer, VehNef(1 To 22) As Integer, VehNcount As Integer, VehStrign As String, Inn As Integer, InnNo As Integer, RowVehNcount As Integer
    global MaxMoveMomHB
    global MaxMoveShrHB
    global SV_Rating
    global Reserve_Factor
    global AXles
    global LorryTimes
    global LorryTimesF
    global incTee

    

    if (SV_Rating == ""):
        #MsgBox "Select SV Rating"
        return 0 

    if (Reserve_Factor == 0):
       #MsgBox "Select Reserve Factor (if unknown set it to 1)"
       return 0 
       #Exit Sub
       
    if (SV_Rating == "SV80" or SV_Rating == "sv80"):
        for I in range(1, 6 + 1):
            Vehicle[I, 1] = 130 * 1.1 * 1.7 / 13 ** 0.15 #'Apply impact factor and 1.1 Overload factor to each wheel
        AXles = 6
        
    if (SV_Rating == "SV100" or SV_Rating == "sv100"):#   ' SV100
        for I in range(1, 6 + 1):
            Vehicle[I, 1] = 165 * 1.1 * 1.7 / 16.5 ** 0.15 #'Apply impact factor and 1.1 Overload factor to each wheel
        AXles = 6
        
    if (SV_Rating == "SV150" or SV_Rating == "sv150"):
        for I in range(1, 10 + 1):
            Vehicle[I, 1] = 146 * 1.1 * 1.7 / (14.6 ** 0.15) #'Apply impact factor and 1.1 Overload factor to each wheel
        AXles = 10
        
    if (SV_Rating == "SVTrain" or SV_Rating == "svtrain"):#                               ' SV-Train
        Vehicle[1, 1] = 100 * 1.1 * 1.7 / 10 ** 0.15 #'Apply impact factor and 1.1 Overload factor to each wheel
        Vehicle[2, 1] = 180 * 1.1 * 1.7 / 18 ** 0.15 #'Apply impact factor and 1.1 Overload factor to each wheel
        Vehicle[3, 1] = 180 * 1.1 * 1.7 / 18 ** 0.15 #'Apply impact factor and 1.1 Overload factor to each wheel
        for I in range(4, 13 + 1):
            Vehicle[I, 1] = 146 * 1.1 * 1.7 / 14.6 ** 0.15 #'Apply impact factor and 1.1 Overload factor to each wheel
        AXles = 13
    
        
    if (SV_Rating == "SVTT" or SV_Rating == "svtt"):#                            ' SV-TT
        Vehicle[1, 1] = 150 * 1.1 * 1.7 / 15 ** 0.15 # 'Apply impact factor and 1.1 Overload factor to each wheel
        Vehicle[2, 1] = 200 * 1.1 * 1.7 / 20 ** 0.15 #'Apply impact factor and 1.1 Overload factor to each wheel
        Vehicle[3, 1] = 200 * 1.1 * 1.7 / 20 ** 0.15 #'Apply impact factor and 1.1 Overload factor to each wheel
        Vehicle[4, 1] = 250 * 1.1 * 1.05
        Vehicle[5, 1] = 250 * 1.1 * 1.05
        AXles = 5
     
    InnNo = 3
    incTee = 0.001
    RowVehNcount = 1
     
    LorryTimes = InnNo * AXles #' Sets number of times the progress lorry crosses the deck
    LorryTimesF = 1.15

    for I in range(1, 25 + 1):
        for J in range(1, 6 + 1):
            MaxMoveMomHB[I, J] = 0
            
        for J in range(1, 5 + 1):
            MaxMoveShrHB[I, J] = 0
        

    for Inn in range(1, InnNo + 1):
        if (InnNo != 1):
            if (Inn == 1):
                inrAxle = 1.2
            elif (Inn == 2):
                inrAxle = 5
            elif (Inn == 3):
                inrAxle = 9

        if (SV_Rating == "SV80" or SV_Rating == "sv80"):#  ' SV80
            Vehicle[1, 2] = 0
            Vehicle[2, 2] = 1.2
            Vehicle[3, 2] = 2.4
            Vehicle[4, 2] = 2.4 + inrAxle
            Vehicle[5, 2] = 3.6 + inrAxle
            Vehicle[6, 2] = 4.8 + inrAxle
            VehicleL = Vehicle[6, 2]
            #VehStrign = "SV80: [ 130 {1.2} 130 {1.2} 130 { " & inrAxle & " } 130 {1.2} 130 {1.2} 130 ]" #*********************************+???????????
             
        if (SV_Rating == "SV100" or SV_Rating == "sv100"): #Then      ' SV100
            Vehicle[1, 2] = 0
            Vehicle[2, 2] = 1.2
            Vehicle[3, 2] = 2.4
            Vehicle[4, 2] = 2.4 + inrAxle
            Vehicle[5, 2] = 3.6 + inrAxle
            Vehicle[6, 2] = 4.8 + inrAxle
            VehicleL = Vehicle[6, 2]
                #VehStrign = "SV100: [ 165 {1.2} 165 {1.2} 165 { " & inrAxle & " } 165 {1.2} 165 {1.2} 165 ]"
             
        if (SV_Rating == "SV150" or SV_Rating == "sv150"): #Then                               ' SV150
            Vehicle[1, 2] = 0
            Vehicle[2, 2] = 1.2
            Vehicle[3, 2] = 2.4
            Vehicle[4, 2] = 3.6
            Vehicle[5, 2] = 4.8
            Vehicle[6, 2] = 4.8 + inrAxle
            Vehicle[7, 2] = 6   + inrAxle
            Vehicle[8, 2] = 7.2 + inrAxle
            Vehicle[9, 2] = 8.4 + inrAxle
            Vehicle[10, 2] = 9.6 + inrAxle
            VehicleL = Vehicle[10, 2]
                #VehStrign = "SV150: [ 146 {1.2} 146 {1.2} 146 {1.2} 146 {1.2} 146 { " & inrAxle & " } 146 {1.2} 146 {1.2} 146 {1.2} 146 {1.2} 146 ]"
             
        if (SV_Rating == "SVTrain" or SV_Rating == "svtrain"):# Then                            ' SV-Train
            Vehicle[1, 2] = 0
            Vehicle[2, 2] = 4.4
            Vehicle[3, 2] = 6
            Vehicle[4, 2] = 10
            Vehicle[5, 2] = 11.2
            Vehicle[6, 2] = 12.4
            Vehicle[7, 2] = 13.6
            Vehicle[8, 2] = 14.8
            Vehicle[9, 2] = 14.8 + inrAxle
            Vehicle[10, 2] = 16 + inrAxle
            Vehicle[11, 2] = 17.2 + inrAxle
            Vehicle[12, 2] = 18.4 + inrAxle
            Vehicle[13, 2] = 19.6 + inrAxle
            VehicleL = Vehicle[13, 2]
                #VehStrign = "SV-Train: [146{1.2}146{1.2}146{1.2}146{1.2}146{ " & inrAxle & " }146{1.2}146{1.2}146{1.2}146{1.2}146{4.0}180{1.6}180{4.4}100]"
             
        if (SV_Rating == "SVTT" or SV_Rating == "svtt"):#Then                 ' SV-TT
            Vehicle[1, 2] = 0
            Vehicle[2, 2] = 4
            Vehicle[3, 2] = 5.5
            Vehicle[4, 2] = 13.5
            Vehicle[5, 2] = 15
            VehicleL = Vehicle[5, 2]
                #VehStrign = "SV-TT: [ 250 {1.5} 250 {8.0} 200 {1.5} 200 {4.0} 150 ]"
            
                
        ImpctFctr = 1.2 / 1.1
        for Iimpct in range(1, AXles + 1):
            if (Iimpct == 1):
                Vehicle[1, 1] = Vehicle[1, 1] * ImpctFctr
            else:
                Vehicle[Iimpct, 1] = Vehicle[Iimpct, 1] * ImpctFctr
                Vehicle[Iimpct - 1, 1] = Vehicle[Iimpct - 1, 1] / ImpctFctr
                
            MovinVehicle()
             
            for I in range(1, (2 * NoSpn + 1) + 1, 2):
                if (MaxMoveMom[I, 1] > MaxMoveMomHB[I, 1]):# Then
                    MaxMoveMomHB[I, 1] = MaxMoveMom[I, 1]# 'Moment                 Max hog
                    MaxMoveMomHB[I, 2] = MaxMoveMom[I, 2]#   'Position of Max moment
                    MaxMoveMomHB[I, 3] = MaxMoveMom[I, 3]#   'First wheel position
                    MaxMoveMomHB[I, 4] = inrAxle         #     'Vehicle configuration
                    if (ImpctFctr > 1.01):# Then
                        MaxMoveMomHB[I, 5] = Iimpct #  'Record which axle has overload factor
                        MaxMoveMomHB[I, 6] = Vehicle[Iimpct, 1] #  'Nominal Axle Load
                if (abs(MaxMoveShr[I, 1]) > abs(MaxMoveShrHB[I, 1])):# Then
                    MaxMoveShrHB[I, 1] = MaxMoveShr[I, 1] # 'Shear                 LHE
                    MaxMoveShrHB[I, 2] = MaxMoveShr[I, 2] #  'First wheel position
                    MaxMoveShrHB[I, 3] = inrAxle          #     'Vehicle configuration
                    if (ImpctFctr > 1.01):# Then
                        MaxMoveShrHB[I, 4] = Iimpct   #'Record which axle has overload factor
                        MaxMoveShrHB[I, 5] = Vehicle[Iimpct, 1] # 'Nominal Axle Load
            
            for I in range(2, (2 * NoSpn) + 1, 2):
                if (MaxMoveMom[I, 1] < MaxMoveMomHB[I, 1]):
                    MaxMoveMomHB[I, 1] = MaxMoveMom[I, 1] # 'Moment                 Max sag
                    MaxMoveMomHB[I, 2] = MaxMoveMom[I, 2] #  'Position of Max moment
                    MaxMoveMomHB[I, 3] = MaxMoveMom[I, 3] #  'First wheel position
                    MaxMoveMomHB[I, 4] = inrAxle           #  'Vehicle configuration
                    if (ImpctFctr > 1.01):
                        MaxMoveMomHB[I, 5] = Iimpct  # 'Record which axle has overload factor
                        MaxMoveMomHB[I, 6] = Vehicle[Iimpct, 1] # 'Nominal Axle Load
                     
                if (abs(MaxMoveShr[I, 1]) > abs(MaxMoveShrHB[I, 1])):
                    MaxMoveShrHB[I, 1] = MaxMoveShr[I, 1] #  'Shear                 RHE
                    MaxMoveShrHB[I, 2] = MaxMoveShr[I, 2] #   'First wheel position
                    MaxMoveShrHB[I, 3] = inrAxle   #              'Vehicle configuration
                    if (ImpctFctr > 1.01):
                        MaxMoveShrHB[I, 4] = Iimpct   #'Record which axle has overload factor
                        MaxMoveShrHB[I, 5] = Vehicle[Iimpct, 1] #  'Nominal Axle Load
                    
                

        Vehicle[AXles, 1] = Vehicle[AXles, 1] / ImpctFctr   #  'reset last axle
        RowVehNcount = RowVehNcount + 1
        #Worksheets("Line Beam").Cells(LineC + RowVehNcount, 1).HorizontalAlignment = xlLeft
        #Worksheets("line beam").Cells(LineC + RowVehNcount, 1) = VehStrign
        #'ActiveSheet.Shapes("lorry").Visible = False
        #'ActiveSheet.Shapes("deck").Visible = False
        #'write output for envelope condition
    lineR = int(InnNo / 2) + 1
    #'Apply Reserve Factor and Gamma F
    GammaF = 1.1
    for I in range(1, (2 * NoSpn + 1) + 1):
        MaxMoveMomHB[I, 1] = GammaF * Reserve_Factor * MaxMoveMomHB[I, 1]
        MaxMoveShrHB[I, 1] = GammaF * Reserve_Factor * MaxMoveShrHB[I, 1]

    #WriteSTGOMulti()
    lineR = 4
    LineC=11

    return MaxMoveMomHB,MaxMoveShrHB

def Load_Vehicle_HB_Fact():

    #Dim inrAxle As Single, Inn As Integer, HB_rating As Integer, GammaF As Single
    global MaxMoveMomHB
    global MaxMoveShrHB
    global AXles
    global LorryTimes
    global LorryTimesF
    global incTee
    global HB_rating


    incTee = 0.001
    #HB_rating = workssheetLB1coma8 #Worksheets("line beam").Cells(1, 8).Value
    GammaF = 1.3

    #'Define only 45HB vehicle, then a proportionate factr will be added
    for I in range(1, 4 + 1):
        Vehicle[I, 1] = HB_rating * 10
     
    AXles = 4


    #'This is only to check if it works (start delete)
    #    For I = 1 To 4
    #        Worksheets("Line Beam").Cells(LineC + 2 * I - 1, 1).HorizontalAlignment = xlRight
    #        Worksheets("line beam").Cells(LineC + 2 * I - 1, 1) = "W" & I
    #        Worksheets("Line Beam").Cells(LineC + 2 * I - 1, 2).HorizontalAlignment = xlCenter
    #        Worksheets("line beam").Cells(LineC + 2 * I - 1, 2) = Vehicle(I, 1)
    #    Next I
    #'Delete up to this point

    for I in range(1, 25 + 1):
        for J in range(1, 3 + 1):
            MaxMoveMomHB[I, J] = 0
            MaxMoveShrHB[I, J] = 0            
        MaxMoveMomHB[I, 4] = 1

    Vehicle[1, 2] = 0
    Vehicle[2, 2] = 1.8
            
                # Worksheets("Line Beam").Cells(LineC + 2, 3).HorizontalAlignment = xlCenter
                # Worksheets("Line Beam").Cells(LineC + 2, 3) = Vehicle(2, 2)
                # Worksheets("Line Beam").Cells(LineC + 4, 3).HorizontalAlignment = xlLeft
                # Worksheets("Line Beam").Cells(LineC + 4, 3) = "6, 11, 16, 21 and 26"
                # Worksheets("Line Beam").Cells(LineC + 6, 3).HorizontalAlignment = xlCenter
                # Worksheets("Line Beam").Cells(LineC + 6, 3) = "1.8"
          
    LorryTimes = 5   #' Sets number of times the progress lorry crosses the deck
    LorryTimesF = 1
          


    for Inn in range(1, 5 + 1):
        inrAxle = 6 + 5 * (Inn - 1)
        Vehicle[3, 2] = 1.8 + inrAxle
        Vehicle[4, 2] = 3.6 + inrAxle
        VehicleL = Vehicle[4, 2]
        MovinVehicle()
        #For I = 1 To 2 * NoSpn + 1 Step 2********************************************************************************************
        for I in range(1, (2 * NoSpn + 1) + 1, 2):
            if (MaxMoveMom[I, 1] > MaxMoveMomHB[I, 1]):
                MaxMoveMomHB[I, 1] = MaxMoveMom[I, 1]   #'Moment                 Max hog
                MaxMoveMomHB[I, 2] = MaxMoveMom[I, 2]   #'Position of Max moment
                MaxMoveMomHB[I, 3] = MaxMoveMom[I, 3]   #'First wheel position
                MaxMoveMomHB[I, 4] = Inn                #'HB configuration
            
            if (abs(MaxMoveShr[I, 1]) > abs(MaxMoveShrHB[I, 1])):
                MaxMoveShrHB[I, 1] = MaxMoveShr[I, 1]   #'Shear                 LHE
                MaxMoveShrHB[I, 2] = MaxMoveShr[I, 2]   #'First wheel position
                MaxMoveShrHB[I, 3] = Inn                #'HB configuration
           
        for I in range(2, (2 * NoSpn) + 1, 2):
            if (MaxMoveMom[I, 1] < MaxMoveMomHB[I, 1]):
                MaxMoveMomHB[I, 1] = MaxMoveMom[I, 1]  # 'Moment                 Max sag
                MaxMoveMomHB[I, 2] = MaxMoveMom[I, 2]  # 'Position of Max moment
                MaxMoveMomHB[I, 3] = MaxMoveMom[I, 3]  # 'First wheel position
                MaxMoveMomHB[I, 4] = Inn               # 'HB configuration

            if (abs(MaxMoveShr[I, 1]) > abs(MaxMoveShrHB[I, 1])):
                MaxMoveShrHB[I, 1] = MaxMoveShr[I, 1] #   'Shear                 RHE
                MaxMoveShrHB[I, 2] = MaxMoveShr[I, 2] #  'First wheel position
                MaxMoveShrHB[I, 3] = Inn              #  'HB configuration
            
   
        #ActiveSheet.Shapes("lorry").Visible = False
        #'ActiveSheet.Shapes("deck").Visible = False
          
    #'write HB output for envelope condition
    lineR = 4
    #'Factorised results: Apply GammaF
    for I in range(1, (2 * NoSpn + 1) + 1):
        MaxMoveMomHB[I, 1] = GammaF * MaxMoveMomHB[I, 1]
        MaxMoveShrHB[I, 1] = GammaF * MaxMoveShrHB[I, 1]

    #'This is only to test the results - Delete
    #WriteHBMulti()**************************************************necesario??

    LineC=11
    

   
    

    return MaxMoveMomHB,MaxMoveShrHB


    # print(MaxMoveMomHB)
    # print("------------- results")
    # for I  in range(1, NoSpn+1):
    #     print("fila: " + str(LineC + 2 * lineR + 2 * I + 4) + " columna: " + str(3) + " valor: " + str(MaxMoveMomHB[2 * I, 1]))
    #     print("fila: " + str(LineC + 2 * lineR + 2 * I + 4) + " columna: " + str(4) + " valor: " + str(MaxMoveMomHB[2 * I, 2]))
    #     print("fila: " + str(LineC + 2 * lineR + 2 * I + 4) + " columna: " + str(5) + " valor: " + str(MaxMoveMomHB[2 * I, 3]))
    
    #Worksheets("Line Beam").Cells(LineC + 2 * lineR + 2 * I + 4, 3) = MaxMoveMomHB(2 * I, 1)
    
def PREPARE_CALCS():
    #Dim NospnNew As Integer
    global NoSpn
    global TotSpn
    global L
    global EIStrt
    global Lleft
    global NoSpnTot

    global workssheetLB6coma2masI
    global workssheetLB5coma2masI
    
    SecCount = 0
    LineC = 11  


    if (OpeninFlag == 0):
        dinput()
    else:
        NospnNew = 0
        for I in range(1, 10 + 1):
            if(workssheetLB4coma2masI[I]!=0):
                NospnNew = NospnNew + 1
        if (NospnNew != NoSpn):    # 'Check to see if spans have been added or subtracted
            dinput()


    #'Input data for span length and EI and determine No of Spans
    TotSpn = 0########**********************creo que se repite en dinput
    for I in range(1, 10 + 1):
        L[I] = workssheetLB4coma2masI[I]
        TotSpn = TotSpn + L[I]        
        EIStrt[I] = workssheetLB5coma2masI[I]
        if (L[I] != 0):
            NoSpn = I
            workssheetLB3coma2masI[I] = I  

    
    if (NoSpn > 1):
        for I in range(1, NoSpn + 1):
            EI[I] = EIStrt[I]

        #'Reduce EI/L's to relative EI/L's
        smallEI = EI[1]
        for I in range(2, NoSpn+1):
            if (EI[I] < smallEI):
                smallEI = EI[I]
        for I in range(1, NoSpn + 1):
            EI[I] = EI[I] / smallEI / L[I]
            workssheetLB6coma2masI[I] = EI[I]

        #'Module2
        distribution()  #'Calculate distribution factors

        #'Calculate accumulative distance from left hand end
        for I in range(1, 10 + 1):
            Lleft[I] = 0
        Lleft[1] = L[1]
        if (NoSpn > 1):
            for I in range(2, NoSpn + 1):
                Lleft[I] = Lleft[I - 1] + L[I]

        
    if (NoSpn == 0):
        for I in range (1, 10 + 1):
            workssheetLB3coma2masI[I] = I  
            workssheetLB4coma2masI[I] = 0  
            workssheetLB5coma2masI[I] = 0  
            workssheetLB6coma2masI[I] = 0  
        
        
    NoSpnTot=NoSpn   

    return 0

def ShearAtSection():
    #Dim LaShr As Double, Wi As Double, LdLen As Double

    #'NoSpnLd = Number of the Span that the Section is being considered
    #'Calculate shears due to reactions
    global Shr
    Shr = 0
    for N in range(1, NoSpnLd + 1):
        Shr = Shr - Rv[N]

    #'Calculate shears due to loads
    for N in range(1, NoLoads + 1):
        if (Loadin[1, N] > NoSpnLd):
            pass
        elif(Loadin[2, N] == 1):
             LaShr = Sectn - (Lleft[int(Loadin[1, N])] - L[int(Loadin[1, N])] + Loadin[4, N])
             if (LaShr > 0):
                 Shr = Shr + Loadin[3, N]
        
def MomAtSection():
    global NoSpnLd
    global Sectn
    global Mom
    #Dim LaMom As Double, Wi As Double, LdLen As Double

    #'Calculate moment due to distributed moments(FEM) and reactions
    if(NoSpnLd == 1):
        Mom = FEM[1, 1] + Rv[1] * Sectn
    else:
        Mom = FEM[1, 1] + Rv[1] * Sectn
        for N in range(2, int(NoSpnLd)+1):
            Mom = Mom + Rv[N] * (Sectn - Lleft[N - 1])

    #'Calculate moments due to loads
    for N in range(1, NoLoads + 1):
        #if (Loadin[1, N] > NoSpnLd):
         #   pass
            #GoTo Line5************************************************************************************************

        if (Loadin[2, N]==1 and Loadin[1, N] <= NoSpnLd):
            LaMom = Sectn - (Lleft[int(Loadin[1, N])] - L[int(Loadin[1, N])] + Loadin[4, N])
            if (LaMom > 0):
                Mom = Mom - Loadin[3, N] * LaMom
   
def Reactn():
    global TotLoad
    global NoSpn
    #Dim Ntmes As Integer, La As Double, Spannon As Integer
    #'zero array
    for N in range(1,NoSpn + 1 + 1):
        Rv[N] = 0
    

    #'calclate reacions
    Rv[NoSpn + 1] = TotLoad
    for N in range(1,NoSpn + 1):
        Rv[N] = -FEM[1, 1] - FEM[N, 2]

        for J in range(1, NoLoads + 1):
            Spannon = Loadin[1, J]
            if (Loadin[2, J] == 1):
                b = L[int(Spannon)] - Loadin[4, J]
                if (round(Lleft[int(Spannon)] - b, 5) < Lleft[N] - 0.0000001):
                    Rv[N] = Rv[N] + (Lleft[N] - Lleft[int(Spannon)] + b) * Loadin[3, J]

            elif (Loadin[2, J] == 2):
                Caseb = L[int(Spannon)]
                if (Round(Lleft[int(Spannon)] - b, 5) < Lleft[N]  - 0.0000001):
                    Rv[N] = Rv[N] + (Lleft[N] - Lleft[int(Spannon)] + b / 2) * Loadin[3, J] * b
            elif (Loadin[2, J] == 3):
                b = L[int(Spannon)] - Loadin[4, J]
                if (Round(Lleft[int(Spannon)] - b, 5) < Lleft[N]  - 0.0000001):
                    Rv[N] = Rv[N] + (Lleft[N] - Lleft[int(Spannon)] + b - Loadin[5, J] / 2) * Loadin[3, J] * Loadin[5, J]
            elif (Loadin[2, J] == 4):
                b = L[int(Spannon)]
                if (Round(Lleft[int(Spannon)] - b, 5) < Lleft[N]  - 0.0000001):
                    Rv[N] = Rv[N] + (Lleft[N] - Lleft[int(Spannon)] + b / 3) * Loadin[3, J] * b / 2
            elif (Loadin[2, J] == 5):
                b = L(int(Spannon))
                if (Round(Lleft(int(Spannon)) - b, 5) < Lleft[N]  - 0.0000001):
                    Rv[N] = Rv[N] + (Lleft[N] - Lleft[int(Spannon)] + 2 * b / 3) * Loadin[3, J] * b / 2
            elif (Loadin[2, J] == 6):
                b = L(int(Spannon))
                if (Round(Lleft(int(Spannon)) - b, 5) < Lleft[N]  - 0.0000001):
                    Rv[N] = Rv[N] + (Lleft[N] - Lleft[int(Spannon)] + b / 2) * Loadin[3, J] * b / 2


        if (N > 1):
            for Ntmes in range(1, N - 1 + 1):
                if (Ntmes == 1):
                    La = Lleft[N]
                else:
                    La = Lleft[N] - Lleft[Ntmes - 1]
                Rv[N] = Rv[N] - Rv[Ntmes] * La

        Rv[N] = Rv[N] / L[N]
        Rv[NoSpn + 1] = Rv[NoSpn + 1] - Rv[N]

def Distribute():
    global FEM1
    global FEM2

    Icount = 0
    Accurcy = 1

    while (Accurcy>0.000000001 and Icount<100):

            #Line1:
            #    Accurcy = 0.00000000001
             #   Icount = Icount + 1
              #  If Icount > 100:
               #     MsgBox Icount
               # Exit Sub

            #'Release joint
        FEM1[1, 1] = -KEI[1, 1] * FEM[1, 1]##KEI y FEM es la calculada en distribution.py??
        FEM1[1, 2] = -KEI[1, 2] * (FEM[1, 2] + FEM[2, 1])
        FEM1[NoSpn, 1] = -KEI[NoSpn, 1] * (FEM[NoSpn - 1, 2] + FEM[NoSpn, 1])
        FEM1[NoSpn, 2] = -KEI[NoSpn, 2] * FEM[NoSpn, 2]

        if (NoSpn > 2):
            for N in range(2,NoSpn - 1 + 1):
                FEM1[N, 1] = -KEI[N, 1] * (FEM[N - 1, 2] + FEM[N, 1])
                FEM1[N, 2] = -KEI[N, 2] * (FEM[N, 2] + FEM[N + 1, 1])

            #'Carry over
        for N in range(1,NoSpn+1):
            if (KEI[N, 1] != 1): 
                FEM2[N, 1] = 0.5 * FEM1[N, 2]
            if (KEI[N, 2] != 1): 
                FEM2[N, 2] = 0.5 * FEM1[N, 1]


            #'Sum moments at supports
        for N in range(1,NoSpn+1):
            FEM[N, 1] = FEM[N, 1] + FEM1[N, 1] + FEM2[N, 1]
            FEM[N, 2] = FEM[N, 2] + FEM1[N, 2] + FEM2[N, 2]

            #'Check accuracy of carry over

        for N in range(1,NoSpn+1):
            if (abs(FEM2[N, 1]) > 0.000000001):
                Accurcy = abs(FEM2[N, 1])
            if (abs(FEM2[N, 2]) > 0.000000001):
                Accurcy = abs(FEM2[N, 2])

            #'Loop until accuracy < 0.000000001
            #if (Accurcy > 0.000000001):
             #   GoTo Line1
            #else:
             #   Exit Sub

        Icount = Icount + 1

def OneSpan():
    global KEI
    #'Check end conditions for pinned or fixed
    if (OPTlhfixed == 1):
        KEI[1, 1] = 0
    if (OPTlhpin == 1):
        KEI[1, 1] = 1

    if (OPTrhfixed == 1):
        KEI[NoSpn, 2] = 0
    if (OPTrhpin == 1):
        KEI[1, 2] = 1

    if (KEI[1, 1] == 0 and KEI[1, 2])== 1:
        FEM[1, 1] = FEM[1, 1] - FEM[1, 2] / 2
        FEM[1, 2] = 0

    if (KEI[1, 1] == 1 and KEI[1, 2] == 0):
        FEM[1, 2] = FEM[1, 2] - FEM[1, 1] / 2
        FEM[1, 1] = 0

    if (KEI[1, 1] == 1 and KEI[1, 2] == 1):
        FEM[1, 1] = 0
        FEM[1, 2] = 0

def FixdEndMomPoint():
    global Intensity
    global a
    global b
    global spnNo
    global FEML
    global FEMR
    FEML = (-Intensity * a * (b ** 2)) / (L[int(spnNo)] ** 2)
    FEMR = (Intensity * b * (a ** 2)) / L[int(spnNo)] ** 2

def Analyse():
    global NoLoads
    global Intensity
    global a 
    global b
    global spnNo
    global FEML
    global FEMR
    global TotLoad
    global NoSpn


   
    #'Module3
    TotLoad = 0
    for I in range(1, NoSpn+1):
        FEM[I, 1] = 0
        FEM[I, 2] = 0

    if (NoSpn > 1) :
        distribution()
    
    for I in range(1,NoLoads+1):
        spnNo = Loadin[1, I]
        Intensity = Loadin[3, I]

        if Loadin[2, I]==1:
            a = Loadin[4, I]
            b = L[int(spnNo)] - a
            TotLoad = TotLoad + Intensity
            FixdEndMomPoint()        
            
            FEM[int(spnNo), 1] = FEM[int(spnNo), 1] + FEML
            FEM[int(spnNo), 2] = FEM[int(spnNo), 2] + FEMR
   
    if (NoSpn > 1):
        Distribute()
    else:
        OneSpan()


    Reactn()

def SortVehLoad():
    global Xsection
    global NoloadsMove
    global Lleft
    global Loadin
    for I in range(1, AXles+1):
            Loadin[1, I] = 1
            for KLOAD in range(1, NoSpn+1):   #'Fill Loadin() with spans that have loads
                if I == 1:
                    if (Xsection > Lleft[KLOAD]):
                        Loadin[1, I] = KLOAD + 1
                else:
                    if (Xsection - Vehicle[I, 2] > Lleft[KLOAD]):
                        Loadin[1, I] = KLOAD + 1
                    if (Xsection - Vehicle[I, 2] < 0):
                        Loadin[1, I] = 0
            Loadin[2, I] = 1  #'All axles are point loads
            Loadin[3, I] = Vehicle[I, 1]   #  'Axle loads in Loadin(3,I)
            

            if (Loadin[1, I] <= NoSpn):
                if (I == 1):
                    Loadin[4, I] = Xsection - (Lleft[int(Loadin[1, I])] - L[int(Loadin[1, I])])
                else:
                    if (Loadin[1, I] > 0):
                        Loadin[4, I] = Xsection - Vehicle[I, 2] - (Lleft[ int(Loadin[1, I])] - L[int(Loadin[1, I])])
            if (Loadin[1, I] > NoSpn):
                Loadin[1, I] = 0
            if (Loadin[4, I] < 0):
                Loadin[1, I] = 0
            if (Loadin[1, I] != 0):
                NoloadsMove = NoloadsMove + 1
                Loadin[1, NoloadsMove] = Loadin[1, I]
                Loadin[2, NoloadsMove] = Loadin[2, I]
                Loadin[3, NoloadsMove] = Loadin[3, I]
                Loadin[4, NoloadsMove] = Loadin[4, I]
    
def MovinVehicle():
    global Xsection
    global NoloadsMove
    global NoLoads
    global NoSpnLd
    global Sectn
    global Mom
    global Shr
    global MaxMoveMom
    global MaxMoveShr
    global TotSpn
    global NoSpn
    global AXles
    global LorryTimes
    global LorryTimesF
    global incTee
    global Loadin

    #Dim Jt, Movecount, LorryInc, LorryIncFF,LorryInc0 ,LorryInc1, PauseTime, Start, Finish, Nii
    

    for I in range(1, (2 * (NoSpn * 2 + 1)) + 1):
        for J in range(1,3+1):
            MaxMoveMom[I, J] = 0
    for I in range(1, (2 * NoSpn) + 1):
         for J in range(1, 2+1):
            MaxMoveShr[I, J] = 0

    AvInc = TotSpn / NoSpn / 100
    LdInc = int(Vehicle[AXles, 2] / AvInc) + 1

    Xsection = 0

    LorryInc0 = (NoSpn * 100 + LdInc) / 20 / LorryTimes
    LorryInc = LorryInc0 * LorryTimes * LorryTimesF
    if LorryTimes > 66 :
        LorryIncFF = 1.15
        LorryInc1 = 30 / LorryTimes
    else:
        LorryInc1 = 24 / LorryTimes
        LorryIncFF = 1
    
    Movecount = 1
    # print("TotSpn: " + str(TotSpn))
    # print("NoSpn: " + str(NoSpn))
    # print("AvInc: " + str(AvInc))
    # print("Vehicle[AXles, 2]: " + str(Vehicle[AXles, 2]))
    # print("int(Vehicle[AXles, 2] / AvInc): " + str(int(Vehicle[AXles, 2] / AvInc)))
    # print("LdInc: " + str(LdInc))
    # print("max jv: " + str(int((NoSpn * 1000 + LdInc))))
    for Jv in range(1,int((NoSpn * 100 + LdInc))+1-1,500): #(le pongo el -1 porque el excel hace algo raro**************************************************************************

        if (LorryInc < Jv):
            Movecount = Movecount + 1
            LorryInc = LorryInc0 * Movecount * LorryTimes * LorryTimesF * LorryIncFF
        Xsection = Xsection + AvInc #       ' position of axle W1
        NoloadsMove = 0     #'Number of loads to move
        
        SortVehLoad()
        NoLoads = NoloadsMove
        Analyse()

        
        #'Calculate Moments
        if (-FEM[1, 1] > MaxMoveMom[1, 1]):
            MaxMoveMom[1, 1] = -FEM[1, 1] #  'Moment                 Max hog R1
            MaxMoveMom[1, 2] = 0      # 'Position of Max moment
            MaxMoveMom[1, 3] = Xsection  #     'First wheel position
     
        for J in range (1,NoSpn+1):
            if FEM[J, 2] > MaxMoveMom[3 + 2 * (J - 1), 1]:
                MaxMoveMom[3 + 2 * (J - 1), 1] = FEM[J, 2] #   'Moment                 Max hog @ Supports
                MaxMoveMom[3 + 2 * (J - 1), 3] = Xsection  #   'First wheel position


        for J in range (1,NoSpn+1):

            MaxMoveMom[3 + 2 * (J - 1), 2] = Lleft[J]   #    'Position of Max moment
        
        for Jx in range (1,NoloadsMove+1):
            NoSpnLd = Loadin[1, Jx]    #       'NoSpnLD = Span number that moments are to be calculted for
            Sectn = Loadin[4, Jx] + Lleft[int(NoSpnLd)] - L[int(NoSpnLd)]
            MomAtSection() #'Module7
            #if Xsection>17.4:
             #   print("Xsection: " + str(Xsection) +  " NoSpnLd: " + str(NoSpnLd) + " Mom: " + str(Mom) + " MaxMoveMom: " + str(MaxMoveMom[2 + 2 * (int(NoSpnLd) - 1), 1]))
              #  if (-Mom < MaxMoveMom[2 + 2 * (int(NoSpnLd) - 1), 1]):
               #     print("****************Xsection: " + str(Xsection))
            if (  -Mom < MaxMoveMom[2 + 2 * (int(NoSpnLd) - 1), 1] ) :  #'In-span sag moments
                #print("entro")
                MaxMoveMom[2 + 2 * (int(NoSpnLd) - 1), 1] = -Mom
                MaxMoveMom[2 + 2 * (int(NoSpnLd) - 1), 2] = Sectn
                MaxMoveMom[2 + 2 * (int(NoSpnLd) - 1), 3] = Xsection
                #if(2 + 2 * (int(NoSpnLd) - 1)==4):
                    #print("________________Xsection: " + str(Xsection))
                    #print("-Mom: -" + str(Mom))
                    #print("MaxMoveMom[2 + 2 * (int(NoSpnLd) - 1), 1]: " + str(MaxMoveMom[2 + 2 * (int(NoSpnLd) - 1), 1]))

    #'Calculate Shears
    
    for Jv  in range(1,AXles+1):
        NoloadsMove = 0     #'Number of loads to move
        Xsection = Vehicle[Jv, 2] + incTee + 0.00001 #' position of axle W1 span 1
        SortVehLoad()
        NoLoads = NoloadsMove
        Analyse()
        for Jx in range(1 ,NoSpn+1):
            Sectn = Lleft[Jx] - L[Jx] + incTee   #' distance from LH end of deck
            NoSpnLd = Jx
            ShearAtSection()    # 'module 7
            if (abs(Shr) > abs(MaxMoveShr[2 * Jx - 1, 1])):
                MaxMoveShr[2 * Jx - 1, 1] = Shr
                MaxMoveShr[2 * Jx - 1, 2] = Xsection
        for Js  in range(1,NoSpn+1):
            NoloadsMove = 0     #'Number of loads to move
            Xsection = Vehicle[Jv, 2] + Lleft[Js] + incTee + 0.00001 #' position of axle W1 in other spans
            SortVehLoad()
            NoLoads = NoloadsMove
            Analyse()
                
            for Jx in range(1,NoSpn+1):
                Sectn = Lleft[Jx] - L[Jx] + incTee  # ' distance from LH end of deck
                NoSpnLd = Jx
                ShearAtSection()    # 'module 7
                if (abs(Shr) > abs(MaxMoveShr[2 * Jx - 1, 1])):
                    MaxMoveShr[2 * Jx - 1, 1] = Shr
                    MaxMoveShr[2 * Jx - 1, 2] = Xsection
        
    for Jv in range(1, AXles+1):
        NoloadsMove = 0     #'Number of loads to move
        Xsection = L[1] + Vehicle[Jv, 2] - incTee - 0.00001 #' position of axle W1 span 1
        SortVehLoad()
        NoLoads = NoloadsMove
        Analyse()
        for Jx in range(1, NoSpn+1):
            Sectn = Lleft[Jx] - incTee   # ' distance from LH end of deck
            NoSpnLd = Jx
            ShearAtSection()    # 'module 7
            if (abs(Shr) > abs(MaxMoveShr[2 * Jx, 1])):
                MaxMoveShr[2 * Jx, 1] = Shr
                MaxMoveShr[2 * Jx, 2] = Xsection

        for Js in range(1, NoSpn+1):
            NoloadsMove = 0   #  'Number of loads to move
            Xsection = Lleft[Js] + Vehicle[Jv, 2] - incTee - 0.00001 #' position of axle W1 in other spans
            SortVehLoad()
            NoLoads = NoloadsMove
            Analyse()
                
            for Jx in range(1,NoSpn+1):
                Sectn = Lleft[Jx] - incTee  #  ' distance from LH end of deck
                NoSpnLd = Jx
                ShearAtSection() #   'module 7
                if (abs(Shr) > abs(MaxMoveShr[2 * Jx, 1])):
                    MaxMoveShr[2 * Jx, 1] = Shr
                    MaxMoveShr[2 * Jx, 2] = Xsection

def distribution():
    global OPTlhfixed
    global OPTlhpin
    global OPTrhfixed
    global OPTrhpin
        
    for I in range(1,11):
        for J in range(1,3):
            KEI[I, J] = 0
            FEM[I, J] = 0

    #'Refix EI reduced values
    for I in range(1, NoSpn+1):
        EI[I] = workssheetLB6coma2masI[I] #Worksheets("Line Beam").Cells(6, 2 + I).Value    

    #'Calculate distribution factors
    #'Check end conditions for pinned or fixed
    if (OPTlhfixed==1): #Worksheets("Line Beam").OptionButtons("OPTlhfixed").Value == xlOn:###si el botón fixed está activo
        KEI[1, 1] = 0
    if (OPTlhpin==1): #Worksheets("Line Beam").OptionButtons("OPTlhpin").Value == xlOn:## si el botón pinned está activo
        KEI[1, 1] = 1
        EI[1] = 0.75 * EI[1]
    
    if (OPTrhfixed==1): #Worksheets("Line Beam").OptionButtons("OPTrhfixed").Value == xlOn: ###si el botón fixed está activo
        KEI[NoSpn, 2] = 0
    if (OPTrhpin==1): #Worksheets("Line Beam").OptionButtons("OPTrhpin").Value == xlOn:## si el botón pinned está activo
        KEI[NoSpn, 2] = 1
        EI[NoSpn] = 0.75 * EI[NoSpn]

    ##############rellenar la matriz KEI##########3
    KEI[1, 2] = EI[1] / (EI[1] + EI[2])
    KEI[NoSpn, 1] = EI[NoSpn] / (EI[NoSpn] + EI[NoSpn - 1])
    if (NoSpn > 2):
        for I in range(2,NoSpn):
            KEI[I, 1] = EI[I] / (EI[I - 1] + EI[I])
            KEI[I, 2] = EI[I] / (EI[I] + EI[I + 1])

def dinput():
    global OpeninFlag
    global NoSpn
    global workssheetLB6coma2masI
    global workssheetLB5coma2masI
    global Lleft
    global L
    global EIStrt

    
    OpeninFlag=OpeninFlag+1
    TotSpn = 0

    for I in range(1, 10 + 1):
        L[I]= workssheetLB4coma2masI[I] # Worksheets("Line Beam").Cells(4, 2 + I).Value
        TotSpn = TotSpn + L[I]
        EIStrt[I]=workssheetLB5coma2masI[I]  # Worksheets("Line Beam").Cells(5, 2 + I).Value
        if L[I] != 0:
            NoSpn = I
            workssheetLB3coma2masI[I] = I #Worksheets("Line Beam").Cells(3, 2 + I) = I    

    if (NoSpn > 1):
        for I in range(1, NoSpn+1):
            EI[I] = EIStrt[I]       
        #'Reduce EI/L's to relative EI/L's
        smallEI = EI[1]
        for I in range(2,NoSpn+1):
            if EI[I] < smallEI:
                smallEI = EI[I]#Busca el valor más pequeño de EIStrt(I) = Worksheets("Line Beam").Cells(5, 2 + I).Value
        for I in range(1,NoSpn+1):
            EI[I] = EI[I] / smallEI / L[I] #cambia el valor de EI(I)=EIStrt(I) = Worksheets("Line Beam").Cells(5, 2 + I).Value  con la fórmula
            #Worksheets("Line Beam").Cells(6, 2 + I).NumberFormat = "0.000"
            workssheetLB6coma2masI[I] = EI[I] #Worksheets("Line Beam").Cells(6, 2 + I).Value = EI(I)##Guarda los valores de EI(I) en Worksheets("Line Beam").Cells(6, 2 + I).Value 
        #'Module2
        distribution()  #'Calculate distribution factors
    
       # 'Calculate accumulative distance from left hand end
    for I in range(1, NoSpn+1):
        Lleft[I] = 0 ##iniciliza la variable Lleft[10]=0
        
    Lleft[1] = L[1] #L(1) = Worksheets("Line Beam").Cells(4, 3).Value
    if (NoSpn > 1):
        for I in range(1,NoSpn+1):
            Lleft[I] = Lleft[I - 1] + L[I]###Lleft(2)=L[1]+L[2] || Lleft(3)=L[1]+L[2]+L[3] || Lleft(4)=L[1]+L[2]+L[3]+L[4] ....

def CALC_SS_HB_AIL():
    global NoSpn
    global sf
    global workssheetLB4coma2masI
    global workssheetLB5coma2masI
    global L

    global EIStrt
    global Lleft
    global EI
    global KEI
    global FEM
    global Vehicle
    global Loadin
    global FEM1
    global FEM2
    global Rv
    global MaxMoveMomHB      
    global MaxMoveShrHB
    global workssheetLB6coma2masI
    global MaxMoveMom
    global MaxMoveShr
    global OpeninFlag

    NoSpnTotf=[]

    v_HB1=[]
    v_SHR1=[]
    v_HB2=[]
    v_SHR2=[]
    v_d_result_HB=[] 
    v_d_result_SHR=[]


    Lcopy=np.zeros(11)
    MaxMoveMomHB11=np.zeros((26,7))
    MaxMoveMomHB22=np.zeros((26,7))
        
    MaxMoveShrHB11=np.zeros((26,6))
    MaxMoveShrHB22=np.zeros((26,6))
    

    NoSpnTot=NoSpn

    for I in range(0,11):
        Lcopy[I]=L[I]

    for J in range(1, NoSpnTot+1):   
        L=np.zeros(11)
        EIStrt=np.zeros(11)
        Lleft=np.zeros(11)
        EI=np.zeros(11)
        KEI=np.zeros((11,3))
        FEM=np.zeros((11,3))
        Vehicle=np.zeros((51,3))
        Loadin=np.zeros((6,101))
        FEM1=np.zeros((11,3))
        FEM2=np.zeros((11,3))
        Rv=np.zeros(12)
        MaxMoveMomHB=np.zeros((26,7))        
        MaxMoveShrHB=np.zeros((26,6))
        workssheetLB6coma2masI=np.zeros(11)
        MaxMoveMom=np.zeros((43,4))
        MaxMoveShr=np.zeros((26,3))
        OpeninFlag=0

        workssheetLB4coma2masI=[0,Lcopy[J],0,0,0,0,0,0,0,0,0]
        workssheetLB5coma2masI=[0,1,0,0,0,0,0,0,0,0,0]
        PREPARE_CALCS()


        if(HB_or_SV=="HB"):
            MaxMoveMomHB1,MaxMoveShrHB1=Load_Vehicle_HB_Fact()
        elif(HB_or_SV=='SV'):
            MaxMoveMomHB1,MaxMoveShrHB1=Load_Vehicle_SV_Fact()


        for I in range(1, 26):
            for JJ in range(1, 7):
                MaxMoveMomHB11[I, JJ] = MaxMoveMomHB1[I, JJ]

        for I in range(1, 26):
            for JJ in range(1, 6):
                MaxMoveShrHB11[I, JJ] = MaxMoveShrHB1[I, JJ]

      

        L=np.zeros(11)
        EIStrt=np.zeros(11)
        Lleft=np.zeros(11)
        EI=np.zeros(11)
        KEI=np.zeros((11,3))
        FEM=np.zeros((11,3))
        Vehicle=np.zeros((51,3))
        Loadin=np.zeros((6,101))
        FEM1=np.zeros((11,3))
        FEM2=np.zeros((11,3))
        Rv=np.zeros(12)
        MaxMoveMomHB=np.zeros((26,7))        
        MaxMoveShrHB=np.zeros((26,6))
        workssheetLB6coma2masI=np.zeros(11)
        MaxMoveMom=np.zeros((43,4))
        MaxMoveShr=np.zeros((26,3))
        OpeninFlag=0
        
        workssheetLB3coma2masI=np.zeros(11)

        PREPARE_CALCS()
        MaxMoveMomHB2,MaxMoveShrHB2=Load_Axles_AIL()

        for I in range(1, 26):
            for JJ in range(1, 7):
                MaxMoveMomHB22[I, JJ] = MaxMoveMomHB2[I, JJ]

        for I in range(1, 26):
            for JJ in range(1, 6):
                MaxMoveShrHB22[I, JJ] = MaxMoveShrHB2[I, JJ]


        HB1, SHR1, HB2, SHR2, d_result_HB, d_result_SHR=comparative(MaxMoveMomHB11,MaxMoveMomHB22,MaxMoveShrHB11,MaxMoveShrHB22)


        v_HB1.append(HB1)
        v_SHR1.append(SHR1)
        v_HB2.append(HB2)
        v_SHR2.append(SHR2)
        v_d_result_HB.append(d_result_HB)
        v_d_result_SHR.append(d_result_SHR)

    return v_HB1, v_SHR1, v_HB2, v_SHR2, v_d_result_HB, v_d_result_SHR

def comparative(MaxMoveMomHB1, MaxMoveMomHB2,MaxMoveShrHB1,MaxMoveShrHB2):
    global sf

    print("................... sf ....................")
    print(sf)

    

    MaxMoveMomHB1_f=np.zeros(( (2*NoSpn)+1 , 3))
    MaxMoveShrHB1_f=np.zeros(( (2*NoSpn)   , 2))
    MaxMoveMomHB2_f=np.zeros(( (2*NoSpn)+1 , 3))
    MaxMoveShrHB2_f=np.zeros(( (2*NoSpn)   , 2))

    #print("*************************comparative****************")
    #print("MaxMoveMomHB1")
    #print(MaxMoveMomHB1)
    #print("MaxMoveShrHB1")
    #print(MaxMoveShrHB1)

    # print("MaxMoveMomHB2")
    # print(MaxMoveMomHB2)

    # print("MaxMoveShrHB2")
    # print(MaxMoveShrHB2)



    v_MaxMoveMomHB1=[]
    v_MaxMoveShrHB1=[]
    v_MaxMoveMomHB2=[]
    v_MaxMoveShrHB2=[]


    for x in range(1,(2*NoSpn)+1+1):
        MaxMoveMomHB1_f[x-1][0]=round(MaxMoveMomHB1[x][1],1)
        MaxMoveMomHB2_f[x-1][0]=round(MaxMoveMomHB2[x][1],1)
        MaxMoveMomHB1_f[x-1][1]=round(MaxMoveMomHB1[x][2],1)
        MaxMoveMomHB2_f[x-1][1]=round(MaxMoveMomHB2[x][2],1)
        MaxMoveMomHB1_f[x-1][2]=round(MaxMoveMomHB1[x][3],1)
        MaxMoveMomHB2_f[x-1][2]=round(MaxMoveMomHB2[x][3],1)

    for x in range(1,(2*NoSpn)+1):
        MaxMoveShrHB1_f[x-1][0]=round(MaxMoveShrHB1[x][1],1)
        MaxMoveShrHB2_f[x-1][0]=round(MaxMoveShrHB2[x][1],1)
        MaxMoveShrHB1_f[x-1][1]=round(MaxMoveShrHB1[x][2],1)
        MaxMoveShrHB2_f[x-1][1]=round(MaxMoveShrHB2[x][2],1)


    #print("*************")
    # print(MaxMoveMomHB1_f)
    # print(MaxMoveShrHB1_f)
    # print(MaxMoveMomHB2_f)
    # print(MaxMoveShrHB2_f)
   
    #Simply-Supported y Continuous(pinned)
    d_result_MaxMoveMomHB={}
    d_result_MaxMoveShrHB={}  

    #print("_______________MaxMoveMomHB_______________")
    for I in range(0, (2 * NoSpn + 1) ):
        if(abs(sf*MaxMoveMomHB1_f[I, 0]) < abs(MaxMoveMomHB2_f[I, 0])):
            #print("FAIL I=" + str(I))
            d_result_MaxMoveMomHB[I]='FAIL'
        else:
            #print("OK I=" + str(I))
            d_result_MaxMoveMomHB[I]='OK'

    #print("_______________MaxMoveShrHB_______________")
    for I in range(0, (2 * NoSpn )):
        if(abs(sf*MaxMoveShrHB1_f[I, 0]) < abs(MaxMoveShrHB2_f[I, 0])):
            #print("FAIL I=" + str(I))
            d_result_MaxMoveShrHB[I]='FAIL'
        else:
            #print("OK I=" + str(I))
            d_result_MaxMoveShrHB[I]='OK'


    
    return MaxMoveMomHB1_f,MaxMoveShrHB1_f,MaxMoveMomHB2_f,MaxMoveShrHB2_f,d_result_MaxMoveMomHB,d_result_MaxMoveShrHB

def HalfJointedSpan(HB_or_SV_hj):
    global Ldds_position
    global Ldds 
    global NoSpn
    global sf
    global workssheetLB4coma2masI
    global workssheetLB5coma2masI
    global L
    global EIStrt
    global Lleft
    global EI
    global KEI
    global FEM
    global Vehicle
    global Loadin
    global FEM1
    global FEM2
    global Rv
    global MaxMoveMomHB      
    global MaxMoveShrHB
    global workssheetLB6coma2masI
    global MaxMoveMom
    global MaxMoveShr
    global OpeninFlag
    global valid_data

    #Dim Ldds As Single, Ldds_position As Integer, Lcant As Single, Mcant1 As Single, Vcant1 As Single, Mcant2 As Single, Vcant2 As Single
    #'Ldds y Ldds_position son variables de entrada




    
    EIStrt=np.zeros(11)
    Lleft=np.zeros(11)
    EI=np.zeros(11)
    KEI=np.zeros((11,3))
    FEM=np.zeros((11,3))
    Vehicle=np.zeros((51,3))
    Loadin=np.zeros((6,101))
    FEM1=np.zeros((11,3))
    FEM2=np.zeros((11,3))
    Rv=np.zeros(12)
    MaxMoveMomHB=np.zeros((26,7))    
    MaxMoveShrHB=np.zeros((26,6))
    workssheetLB6coma2masI=np.zeros(11)
    MaxMoveMom=np.zeros((43,4))
    MaxMoveShr=np.zeros((26,3))
    OpeninFlag=0


    MaxMoveMomHB11=np.zeros((26,7))
    MaxMoveMomHB22=np.zeros((26,7))
        
    MaxMoveShrHB11=np.zeros((26,6))
    MaxMoveShrHB22=np.zeros((26,6))

    #'Comparar que Ldds_position <= NoSpn
    #'Comaparar que Ldds <= L(Ldds_position)
    if(Ldds_position<=NoSpn) and (Ldds<=L[Ldds_position]):
        valid_data=1
    else:
        valid_data=0

    print('valid_data')
    print(valid_data)


    if (valid_data==1):
        Lcant = (L[Ldds_position] - Ldds) / 2
    
        workssheetLB4coma2masI=[0,Ldds,0,0,0,0,0,0,0,0,0]
        workssheetLB5coma2masI=[0,1,0,0,0,0,0,0,0,0,0]
        PREPARE_CALCS()

        

        if(HB_or_SV_hj=='HB'):
            MaxMoveMomHB1,MaxMoveShrHB1=Load_Vehicle_HB_Fact()
        elif(HB_or_SV_hj=='SV'):
            MaxMoveMomHB1,MaxMoveShrHB1=Load_Vehicle_SV_Fact()



        for I in range(1, 26):
            for JJ in range(1, 7):
                MaxMoveMomHB11[I, JJ] = MaxMoveMomHB1[I, JJ]

        for I in range(1, 26):
            for JJ in range(1, 6):
                MaxMoveShrHB11[I, JJ] = MaxMoveShrHB1[I, JJ]

        L=np.zeros(11)
        EIStrt=np.zeros(11)
        Lleft=np.zeros(11)
        EI=np.zeros(11)
        KEI=np.zeros((11,3))
        FEM=np.zeros((11,3))
        Vehicle=np.zeros((51,3))
        Loadin=np.zeros((6,101))
        FEM1=np.zeros((11,3))
        FEM2=np.zeros((11,3))
        Rv=np.zeros(12)
        MaxMoveMomHB=np.zeros((26,7))        
        MaxMoveShrHB=np.zeros((26,6))
        workssheetLB6coma2masI=np.zeros(11)
        MaxMoveMom=np.zeros((43,4))
        MaxMoveShr=np.zeros((26,3))
        OpeninFlag=0########?????
        
        workssheetLB3coma2masI=np.zeros(11)


        PREPARE_CALCS()
        MaxMoveMomHB2,MaxMoveShrHB2=Load_Axles_AIL()

        

        for I in range(1, 26):
            for JJ in range(1, 7):
                MaxMoveMomHB22[I, JJ] = MaxMoveMomHB2[I, JJ]

        for I in range(1, 26):
            for JJ in range(1, 6):
                MaxMoveShrHB22[I, JJ] = MaxMoveShrHB2[I, JJ]

        #'CALL HERE COMPARATIVE COMMAND
        HB1, SHR1, HB2, SHR2, d_result_HB, d_result_SHR=comparative(MaxMoveMomHB11, MaxMoveMomHB22,MaxMoveShrHB11,MaxMoveShrHB22)


        #'Tehn Additional Cantilever Calcs

        Vcant1 = max(abs(MaxMoveShrHB11[1, 1]), abs(MaxMoveShrHB11[2, 1]))
        Mcant1 = Vcant1 * Lcant

        Vcant2 = max(abs(MaxMoveShrHB22[1, 1]), abs(MaxMoveShrHB22[2, 1]))       
        Mcant2 = Vcant2 * Lcant

        

        #'Now compare both Vcant and Mcant

        if (abs(sf * Vcant1) >= abs(Vcant2)) and (abs(sf * Mcant1) >= abs(Mcant2)):
            Result_HJ = "OK"
            print("OK")
        else:
            Result_HJ = "FAIL"
            print("FAIL")

        return HB1, SHR1, HB2, SHR2, d_result_HB, d_result_SHR,Result_HJ, Vcant1, Vcant2, Mcant1, Mcant2
    else:
        return 0, 0, 0, 0, 0, 0, 0

def extract_element_from_json(obj, path):

    def extract(obj, path, ind, arr):
        key = path[ind]
        if ind + 1 < len(path):
            if isinstance(obj, dict):
                if key in obj.keys():
                    extract(obj.get(key), path, ind + 1, arr)
                else:
                    arr.append(None)
            elif isinstance(obj, list):
                if not obj:
                    arr.append(None)
                else:
                    for item in obj:
                        extract(item, path, ind, arr)
            else:
                arr.append(None)
        if ind + 1 == len(path):
            if isinstance(obj, list):
                if not obj:
                    arr.append(None)
                else:
                    for item in obj:
                        arr.append(item.get(key, None))
            elif isinstance(obj, dict):
                arr.append(obj.get(key, None))
            else:
                arr.append(None)
        return arr
    if isinstance(obj, dict):
        return extract(obj, path, 0, [])
    elif isinstance(obj, list):
        outer_arr = []
        for item in obj:
            outer_arr.append(extract(item, path, 0, []))
        return outer_arr

def get_Json_Data(jsontochoose):

    global workssheetLB10masIcoma22
    global workssheetLB10masIcoma24

    global workssheetLB4coma2masI
    global workssheetLB5coma2masI

    global d_workssheetLB4coma2masI
    global d_workssheetLB5coma2masI
    global d_HB_or_SV
    global d_HB_or_SV_value
    global total_structures
    global notice_reference
    global StructureKey
    global StructureType
    global vehicle_assessed

    global d_Span_SVRating
    global timestamp
    global ESRN


    folder_url='C:/Users/Jesus.PINA-MUNOZ/Desktop/Esdal/'+jsontochoose

    with open(folder_url) as json_file:



        data = json.load(json_file)
        
        notice_reference=extract_element_from_json(data, ["properties", "movement_id"])
        StructureKey=extract_element_from_json(data, ["properties", "EsdalStructure", "StructureKey"])
        StructureType=extract_element_from_json(data, ["properties", "EsdalStructure", "StructureType"])
        timestamp=extract_element_from_json(data, ["properties", "timestamp"])
        ESRN=extract_element_from_json(data, ["properties", "EsdalStructure", "ESRN"])

        vehicle_assessed=extract_element_from_json(data, ["properties", "Vehicles", "ConfigurationSummaryListPosition", "ConfigurationSummary"])

        print("-------------------------------VEHICULO-----------------------------")
        d1=0
        workssheetLB10masIcoma22=np.zeros(31)
        workssheetLB10masIcoma24=np.zeros(31)
        workssheetLB4coma2masI=np.zeros(11)
        




        ###########Vector W y S##################
        number_Axles_longitude=extract_element_from_json(data, ["properties", "Vehicles", "Configuration","ComponentListPosition", "Component", "Longitude"])
       # print("number_Axles_longitude") 
       # print(number_Axles_longitude)   
        number_Axles=extract_element_from_json(data, ["properties", "Vehicles", "Configuration","ComponentListPosition", "Component", "AxleConfiguration","NumberOfAxles"])
       # print("number_Axles")
       # print(number_Axles)
        number_Axles_Value_count=extract_element_from_json(data, ["properties", "Vehicles", "Configuration","ComponentListPosition", "Component", "AxleConfiguration","AxleWeightListPosition","AxleWeight","AxleCount"])
       # print("number_Axles_Value_count")
       #  print(number_Axles_Value_count)
        number_Axles_Value_value=extract_element_from_json(data, ["properties", "Vehicles", "Configuration","ComponentListPosition", "Component", "AxleConfiguration","AxleWeightListPosition","AxleWeight","value"])
        # print("number_Axles_Value_value")
       #  print(number_Axles_Value_value)

        for x in range(0,len(number_Axles_Value_value)):
            number_Axles_Value_value[x]=number_Axles_Value_value[x]/100

        ##########poner en orden correcto según longitud#####
        print("")
        maxlongitud=np.amax(number_Axles_longitude)
        d = {}
        d1= {}
        d2= {}

        for i in range(1, maxlongitud+1):
            for x in range(0, len(number_Axles_longitude)):
                if (i==int(number_Axles_longitude[x])):
                    d[i]=number_Axles[x]
        ############
        startcount=0
        a=0
        b=0
        fin=0
        vector2=[]
        vector3=[]
        for i in range(0, len(number_Axles)):
            a=int(number_Axles[i])
            fin=0
            for x in range(startcount, len(number_Axles_Value_count)):
                if fin==0:
                    b=b+int(number_Axles_Value_count[x])
                    #d1[a].append(number_Axles_Value_count[x])
                    vector2.append(number_Axles_Value_count[x]) 
                    vector3.append(number_Axles_Value_value[x])
                    if (b==a):
                        d1[a]=vector2
                        d2[a]=vector3
                        vector2=[]
                        vector3=[]
                        startcount=x+1
                        b=0
                        fin=1
                


        ####modificar los vectores anteriores pero ahora ordenados según longitud####
        number_Axles=[]
        number_Axles_Value_count=[]
        number_Axles_Value_value=[]
        for i in range(1, maxlongitud+1):
            number_Axles.append(d[i])
            for keyd1 in d1:
                if(d[i]==keyd1):
                    for xx in d1[keyd1]:
                        number_Axles_Value_count.append(xx)
            for keyd2 in d2:
                if(d[i]==keyd2):
                    for yy in d2[keyd2]:
                        number_Axles_Value_value.append(yy)

        # print("number_Axles")
       # print(number_Axles)
       #  print("number_Axles_Value_count")
       #  print(number_Axles_Value_count)
       #  print("number_Axles_Value_value")
       #  print(number_Axles_Value_value)

        ####Calculo de los vectores finales####

        total_NA_values=0
        i=0
        total_Count=0
        contadorinicio=0
        fin_v1=1

        for N_A in number_Axles:
            v1=int(N_A)
            fin_v1=0
            for N_A_Count in range (contadorinicio, len(number_Axles_Value_count)):
                if fin_v1==0:
                    v2=int(number_Axles_Value_count[N_A_Count])  
                    v3=int(number_Axles_Value_value[N_A_Count]) 
                    for x in range(0,v2):
                        i=i+1
                        workssheetLB10masIcoma22[i]=v3
                    total_Count=total_Count+v2

                    if (total_Count>=v1):                       
                        contadorinicio=N_A_Count+1
                        total_Count=0
                        fin_v1=1
                        break               
        print("workssheetLB10masIcoma22")
        print(workssheetLB10masIcoma22)
        print("")


        ###########################################DISTANCIA DE EJES#####################################################
        number_Axles2=extract_element_from_json(data, ["properties", "Vehicles", "Configuration","ComponentListPosition", "Component", "AxleConfiguration","NumberOfAxles"])
        # print("number_Axles2")
        # print(number_Axles2)

        number_Axles_Spacing_Count=extract_element_from_json(data, ["properties", "Vehicles", "Configuration","ComponentListPosition", "Component", "AxleConfiguration","AxleSpacingListPosition","AxleSpacing","AxleCount"])
        # print(number_Axles_Spacing_Count)


        number_Axles_Spacing_Value=extract_element_from_json(data, ["properties", "Vehicles", "Configuration", "ComponentListPosition", "Component", "AxleConfiguration","AxleSpacingListPosition","AxleSpacing","value"])
        # print(number_Axles_Spacing_Value)

        number_Axles_Spacing_toFollowing=extract_element_from_json(data, ["properties", "Vehicles", "Configuration","ComponentListPosition", "Component", "AxleConfiguration","AxleSpacingToFollowing"])
        # print(number_Axles_Spacing_toFollowing)




        ##########crear diccionarios para ordenarlos#####
        print("")
        maxlongitud=np.amax(number_Axles_longitude)
        d_spacing_to_following = {}

        for i in range(1, maxlongitud+1):
            for x in range(0, len(number_Axles_longitude)):
                if (i==int(number_Axles_longitude[x])):
                    d_spacing_to_following[i]=number_Axles_Spacing_toFollowing[x]

        
        d1= {}
        d2= {}

        startcount=0
        a=0
        b=0
        fin=0
        vector2=[]
        vector3=[]
        for i in range(0, len(number_Axles2)):
            a=int(number_Axles2[i])
            fin=0
            for x in range(startcount, len(number_Axles_Spacing_Count)):
                if fin==0:
                    b=b+int(number_Axles_Spacing_Count[x])
                    #d1[a].append(number_Axles_Value_count[x])
                    vector2.append(number_Axles_Spacing_Count[x]) 
                    vector3.append(number_Axles_Spacing_Value[x])
                    if (b+1==a):
                        d1[a]=vector2
                        d2[a]=vector3
                        vector2=[]
                        vector3=[]
                        startcount=x+1
                        b=0
                        fin=1
                


        ####modificar los vectores anteriores pero ahora ordenados según longitud####
        number_Axles2=[]
        number_Axles_Spacing_Count=[]
        number_Axles_Spacing_Value=[]
        number_Axles_Spacing_toFollowing=[]
        for i in range(1, maxlongitud+1):
            number_Axles2.append(d[i])
            number_Axles_Spacing_toFollowing.append(d_spacing_to_following[i])
            for keyd1 in d1:
                if(d[i]==keyd1):
                    for xx in d1[keyd1]:
                        number_Axles_Spacing_Count.append(xx)
            for keyd2 in d2:
                if(d[i]==keyd2):
                    for yy in d2[keyd2]:
                        number_Axles_Spacing_Value.append(yy)


        for N_A in number_Axles2:
            v1=int(N_A)
            fin_v1=0
            for N_A_Count in range (contadorinicio, len(number_Axles_Spacing_Count)):
                if fin_v1==0:
                    v2=int(number_Axles_Spacing_Count[N_A_Count])  
                    v3=int(number_Axles_Spacing_Value[N_A_Count])   
                    for x in range(0,v2):
                        i=i+1
                        workssheetLB10masIcoma22[i]=v3
                    total_Count=total_Count+v2

                    if (total_Count>=v1):                       
                        contadorinicio=N_A_Count+1
                        total_Count=0
                        fin_v1=1
                        break           


       #  print("number_Axles2")
       #  print(number_Axles2)
       #  print("number_Axles_Spacing_Count")
        # print(number_Axles_Spacing_Count)
       #  print("number_Axles_Spacing_Value")
       #  print(number_Axles_Spacing_Value)   
       #  print("number_Axles_Spacing_toFollowing")
       #  print(number_Axles_Spacing_toFollowing) 
       #  print("")

        #####cálculo de los vectores finales#########
        total_NA_values=0
        i=0
        total_Count=0
        contadorinicio=0
        fin_v1=1
        i_spacing=0

        for N_A in number_Axles:
            v1=int(N_A)
            fin_v1=0
            for N_A_Count in range (contadorinicio, len(number_Axles_Spacing_Count)):
                if fin_v1==0:
                    v2=int(number_Axles_Spacing_Count[N_A_Count])  
                    v3=float(number_Axles_Spacing_Value[N_A_Count]) 
                    for x in range(0,v2):
                        i=i+1
                        workssheetLB10masIcoma24[i]=v3
                    total_Count=total_Count+v2

                    if (total_Count+1==v1):   
                        i=i+1   
                        if (str(number_Axles_Spacing_toFollowing[i_spacing])!='None'):
                            #print("number_Axles_Spacing_toFollowing: " + str(number_Axles_Spacing_toFollowing[i_spacing]))
                            workssheetLB10masIcoma24[i]=(number_Axles_Spacing_toFollowing[i_spacing])
                        else:
                            workssheetLB10masIcoma24[i]=0

                        i_spacing=i_spacing+1
                        contadorinicio=N_A_Count+1
                        total_Count=0
                        fin_v1=1
                        break

        print("workssheetLB10masIcoma24")
        print(workssheetLB10masIcoma24)
        print("")
        print("")







        #################Estructura##############

        print("-------------------------------ESTRUCTURA-----------------------------")

        Span_SequencePosition=extract_element_from_json(data, ["properties", "EsdalStructure", "UnderbridgeSections","UnderbridgeSection", "Span", "SpanPosition","SequencePosition"])
        #print("Span_SequencePosition")  
        #print(Span_SequencePosition)    
        Span_Lenght=extract_element_from_json(data, ["properties", "EsdalStructure", "UnderbridgeSections","UnderbridgeSection", "Span", "Length"])
        #print("Span_Lenght")
        #print(Span_Lenght)
        Span_StructureType=extract_element_from_json(data, ["properties", "EsdalStructure", "UnderbridgeSections","UnderbridgeSection", "Span", "StructureType"])
        #print("Span_StructureType")
        #print(Span_StructureType)
        Span_Construction=extract_element_from_json(data, ["properties", "EsdalStructure", "UnderbridgeSections","UnderbridgeSection", "Span", "Construction"])
        #print("Span_Construction")
        #print(Span_Construction)

        Span_HBRating=extract_element_from_json(data, ["properties", "EsdalStructure", "UnderbridgeSections","UnderbridgeSection", "LoadRating", "HBRatingWithLoad"])
        # print("Span_HBRating")
        # print(Span_HBRating)

        Span_SVRating_ignored=extract_element_from_json(data, ["properties", "EsdalStructure", "UnderbridgeSections","UnderbridgeSection", "LoadRating", "SVRating"])
        # print("Span_SVRating_ignored")
        # print(Span_SVRating_ignored)

        Span_SVRating_valid=extract_element_from_json(data, ["properties", "EsdalStructure", "UnderbridgeSections","UnderbridgeSection", "LoadRating", "SVParameters", "VehicleType"])
        # print("Span_SVRating_valid")
        # print(Span_SVRating_valid)

        Span_SVReserve=extract_element_from_json(data, ["properties", "EsdalStructure", "UnderbridgeSections","UnderbridgeSection", "LoadRating", "SVParameters", "SVReserveWithLoad"])
        # print("Span_SVReserve")
        # print(Span_SVReserve)


        #print("")
        
        total_structures=0

        for x in range(0, len(Span_SequencePosition)):
            if (1==int(Span_SequencePosition[x])):
                total_structures=total_structures+1 


        d_estructure_spans={}
        d2_estructure_spans={}
        v_estructure_spans=[]
        v2_estructure_spans=[]

        d_estructure_Type={}
        v_estructure_Type=[]
        d_structure_Construction={}
        v_estructure_Construction=[]


        repetido=[]
        cambio=0
        no_entra=0
        x=1
        
        for y in range(0, len(Span_SequencePosition)):
            span_seq_count=Span_SequencePosition[y]
            span_seq_value=Span_Lenght[y]
            span_seq_type=Span_StructureType[y]
            span_seq_construction=Span_Construction[y]
            cambio=0
            for v in repetido:
                if span_seq_count==v:
                    cambio=1
            if cambio==0:
                #print(span_seq_count)
                v_estructure_spans.append(span_seq_count)
                v2_estructure_spans.append(span_seq_value)
                v_estructure_Type.append(span_seq_type)
                v_estructure_Construction.append(span_seq_construction)
                repetido.append(span_seq_count)
            else:
                d_estructure_spans[x]=v_estructure_spans
                d2_estructure_spans[x]=v2_estructure_spans
                d_estructure_Type[x]=v_estructure_Type
                d_structure_Construction[x]=v_estructure_Construction
                x=x+1
                v_estructure_spans=[]
                v2_estructure_spans=[]
                v_estructure_Type=[]
                v_estructure_Construction=[]
                v_estructure_spans.append(span_seq_count)
                v2_estructure_spans.append(span_seq_value)
                v_estructure_Type.append(span_seq_type)
                v_estructure_Construction.append(span_seq_construction)
                repetido=[]
                repetido.append(span_seq_count)
        d_estructure_spans[x]=v_estructure_spans
        d2_estructure_spans[x]=v2_estructure_spans
        d_estructure_Type[x]=v_estructure_Type
        d_structure_Construction[x]=v_estructure_Construction


        
        # print(d_estructure_spans)
        # print("++")
        # print(d2_estructure_spans)
       #  print("++")
       #  print(d_estructure_Type)
       #  print("++")
        # print(d_structure_Construction)

        v1_f=[]
        d1_f={}
        v2_f=[]
        d2_f={}

        d_estructure_Type_f={}
        v_estructure_Type_f=[]
        d_structure_Construction_f={}
        v_estructure_Construction_f=[]
        print("")


        for x in range(1,total_structures+1):
            maxspan=np.amax(d_estructure_spans[x])

            for y in range(1,maxspan+1):
                for v in range(0,len(d_estructure_spans[x])):
                    value=d_estructure_spans[x][v]
                    if y==value:
                        v1_f.append(value)
                        v2_f.append(d2_estructure_spans[x][v])
                        v_estructure_Type_f.append(d_estructure_Type[x][v])
                        v_estructure_Construction_f.append(d_structure_Construction[x][v])
            d1_f[x]=v1_f
            v1_f=[]
            d2_f[x]=v2_f
            v2_f=[]
            d_estructure_Type_f[x]=v_estructure_Type_f
            v_estructure_Type_f=[]
            d_structure_Construction_f[x]=v_estructure_Construction_f
            v_estructure_Construction_f=[]


        


        d_Span_SVRating={}
        d_Span_HBRating={}
        d_Span_SVReserve={}
        #######comprobar los SVrating ignored y valid y crear el bueno en un diccionario####
        for x in range(0,len(Span_SVRating_valid)):
            d_Span_HBRating[x+1]=Span_HBRating[x]
            d_Span_SVReserve[x+1]=Span_SVReserve[x]
            if(str(Span_SVRating_valid[x])!='None' and str(Span_SVRating_valid[x])!=''):
                d_Span_SVRating[x+1]=Span_SVRating_valid[x]
            else:
                if(str(Span_SVRating_ignored[x])!='None' and str(Span_SVRating_ignored[x])!=''):
                    d_Span_SVRating[x+1]=Span_SVRating_ignored[x]
                else:
                    d_Span_SVRating[x+1]='None'

        print('d_Span_SVReserve')
        print(d_Span_SVReserve)
        print('d_Span_HBRating')
        print(d_Span_HBRating)

        



        #print(d1_f)
        #print(d2_f)
        print(d_estructure_Type_f)
        print(d_structure_Construction_f)

        
        # print(d_Span_SVRating)
        # print("hb rating")
        # print(d_Span_HBRating)
        # print("sv rating")
        # print(d_Span_SVReserve)

        d_workssheetLB4coma2masI={}
        v_workssheetLB4coma2masI=np.zeros(11)

        d_workssheetLB5coma2masI={}
        v_workssheetLB5coma2masI=np.zeros(11)
        d_HB_or_SV={}
        d_HB_or_SV_value={}


        print(" ")

        for i in range(1,total_structures+1):
            for x in range(0,len(d2_f[i])): 
                v_workssheetLB4coma2masI[x+1]=d2_f[i][x]
                v_workssheetLB5coma2masI[x+1]=1
            
            d_workssheetLB4coma2masI[i]=v_workssheetLB4coma2masI
            v_workssheetLB4coma2masI=np.zeros(11)

            d_workssheetLB5coma2masI[i]=v_workssheetLB5coma2masI
            v_workssheetLB5coma2masI=np.zeros(11)


        for i in range(1,total_structures+1):  
            if( str(d_Span_SVReserve[i])!='' and str(d_Span_SVReserve[i])!='None' ):
                d_HB_or_SV[i]='SV'
                d_HB_or_SV_value[i]=d_Span_SVReserve[i]
            elif( str(d_Span_HBRating[i])!='None' or str(d_Span_HBRating[i])!='' ):
                d_HB_or_SV[i]='HB'
                d_HB_or_SV_value[i]=d_Span_HBRating[i]



        print(d_workssheetLB4coma2masI)
        print(d_workssheetLB5coma2masI)
        print(d_HB_or_SV)
        print(d_HB_or_SV_value)
        print("------------------------------------------")
        print("")

def writejson():
    global timestamp
    global ESRN

    global global_status
    data={}
    esdalstructureresults={}
    dateTimeObj = datetime.now()

    for i in range(1,total_structures+1):
        str_current_status= d_current_status[i]
        str_current_status_hb= d_current_status_hb[i]
        str_current_status_shr= d_current_status_shr[i]
        esdalstructureresults['EsdalStructure ' + str(i)] = []
        esdalstructureresults['EsdalStructure ' + str(i)].append({
        'ESRN': ESRN[i-1],
        'StructureKey':StructureKey[i-1] ,
        'result structure':str_current_status ,
        "result mom":str_current_status_hb,
        "result shear":str_current_status_shr
        })

    for i in range(1,1+1):
        data['properties'] = []
        data['properties'].append({
        "timestamp": timestamp[0],
        "timestamp_finish":str(dateTimeObj) ,
        "movement_id":notice_reference ,
        "global result": global_status,
        "cautions":" ",
        "comments":" "})

        data['properties'].append(esdalstructureresults)

    datatext=notice_reference+'.json'

    with open('datatext.txt', 'w') as outfile:
        json.dump(data, outfile)


@login_required
def command(request):
    global structure
    global d_current_status_l
    global d_StructureKey_l

    d_StructureKey_l={}
    d_StructureKey_l=d_StructureKey

    d_current_status_l=d_current_status
    

    structure=request.POST['structure']
    structure=int(structure)



    return render(request, 'result.html',{'structure':structure, 'd_StructureKey':d_StructureKey, 'd_current_status':d_current_status ,'d_HB_or_SV':d_HB_or_SV, 'd_HB_or_SV_value':d_HB_or_SV_value,  'notice_reference':notice_reference,'d_r_St_type':d_r_St_type, 'd_r_HB1':d_r_HB1, 'd_r_text_HB':d_r_text_HB,\
    'd_r_HB2':d_r_HB2, 'd_r_d_result_HB':d_r_d_result_HB,'d_r_SHR1':d_r_SHR1 ,'d_r_text_SHR':d_r_text_SHR, 'd_r_SHR2':d_r_SHR2, 'd_r_d_result_SHR':d_r_d_result_SHR,\
    'vehicle_assessed':vehicle_assessed, 'd_r_text_HB_pin':d_r_text_HB_pin,'d_r_text_SHR_pin': d_r_text_SHR_pin, 'd_r_HB1_pin':d_r_HB1_pin,'d_r_SHR1_pin':d_r_SHR1_pin,\
    'd_r_HB2_pin':d_r_HB2_pin, 'd_r_SHR2_pin':d_r_SHR2_pin, 'd_r_d_result_HB_pin': d_r_d_result_HB_pin,'d_r_d_result_SHR_pin': d_r_d_result_SHR_pin,\
    'd_r_text_HB_fix':d_r_text_HB_fix,'d_r_text_SHR_fix': d_r_text_SHR_fix, 'd_r_HB1_fix':d_r_HB1_fix,'d_r_SHR1_fix':d_r_SHR1_fix, 'd_r_HB2_fix':d_r_HB2_fix,\
    'd_r_SHR2_fix':d_r_SHR2_fix, 'd_r_d_result_HB_fix': d_r_d_result_HB_fix, 'd_r_d_result_SHR_fix': d_r_d_result_SHR_fix, 'd_fallaContinouos':d_fallaContinouos,\
    'd_r_HB1_hjs':d_r_HB1_hjs, 'd_r_SHR1_hjs':d_r_SHR1_hjs, 'd_r_HB2_hjs':d_r_HB2_hjs, 'd_r_SHR2_hjs':d_r_SHR2_hjs, 'd_r_d_result_HB_hjs':d_r_d_result_HB_hjs,\
    'd_r_d_result_SHR_hjs':d_r_d_result_SHR_hjs, 'd_r_Result_HJ_hjs':d_r_Result_HJ_hjs, 'd_r_text_HB_hjs': d_r_text_HB_hjs, 'd_r_text_SHR_hjs':d_r_text_SHR_hjs,\
    'd_current_status_hb':d_current_status_hb, 'd_current_status_shr':d_current_status_shr, 'd_sf':d_sf, 'd_Span_SVRating':d_Span_SVRating,\
    'd_estructure_Type_convert':d_estructure_Type_convert, 'd_current_status_hb_hjs': d_current_status_hb_hjs, 'd_current_status_shr_hjs':d_current_status_shr_hjs,\
    'd_ldds_f':d_ldds_f, 'd_ldds_position_f':d_ldds_position_f, 'valid_data':valid_data, 'd_extra_check_hj':d_extra_check_hj})

@login_required
def start(request):
    #St_type= request.GET["num1"]  

    if 'json1' in request.POST:
        jsontochoose='inputjson1.json'
        # do subscribe
    elif 'json2' in request.POST:
        jsontochoose='inputjson2.json'



    #######################################################    

    
    global MaxMoveMomHB11
    global MaxMoveShrHB11
    global MaxMoveMomHB22
    global MaxMoveShrHB22
    global OpeninFlag
    global workssheetLB4coma2masI
    global workssheetLB5coma2masI
    global HB_rating
    global Reserve_Factor
    global HB_or_SV
    global notice_reference
    global StructureKey
    global StructureType
    global vehicle_assessed
    global sf
    global Ldds
    global Ldds_position


    global OPTlhfixed
    global OPTlhpin
    global OPTrhfixed
    global OPTrhpin
    global d_Span_SVRating
    global SV_Rating



    global d_StructureKey
    global d_current_status 
    global d_HB_or_SV
    global d_HB_or_SV_value
    global d_r_St_type
    global d_r_HB1 
    global d_r_text_HB
    global d_r_HB2
    global d_r_d_result_HB
    global d_r_SHR1
    global d_r_text_SHR
    global d_r_SHR2
    global d_r_d_result_SHR
    global vehicle_assessed
    global d_r_text_HB_pin
    global d_r_text_SHR_pin
    global d_r_HB1_pin
    global d_r_SHR1_pin
    global d_r_HB2_pin
    global d_r_SHR2_pin
    global d_r_d_result_HB_pin
    global d_r_d_result_SHR_pin
    global d_r_text_HB_fix
    global d_r_text_SHR_fix
    global d_r_HB1_fix
    global d_r_SHR1_fix
    global d_r_HB2_fix
    global d_r_SHR2_fix
    global d_r_d_result_HB_fix
    global d_r_d_result_SHR_fix
    global d_fallaContinouos
    global d_r_HB1_hjs
    global d_r_SHR1_hjs
    global d_r_HB2_hjs
    global d_r_SHR2_hjs
    global d_r_d_result_HB_hjs
    global d_r_d_result_SHR_hjs
    global d_r_Result_HJ_hjs
    global d_r_text_HB_hjs
    global d_r_text_SHR_hjs
    global d_current_status_hb
    global d_current_status_shr
    global d_sf
    global d_Span_SVRating
    global d_estructure_Type_convert
    global d_current_status_hb_hjs
    global d_current_status_shr_hjs
    global valid_data
    global global_status
    global d_extra_check_hj

    global d_ldds_f
    global d_ldds_position_f

    valid_data=1



    ####################GET JSON DATA#########################################
    get_Json_Data(jsontochoose)




    print(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::")
    print(StructureKey)


    d_r_HB1={}
    d_r_SHR1={}
    d_r_HB2={} 
    d_r_SHR2={} 
    d_r_d_result_HB={} 
    d_r_d_result_SHR={}


    d_r_HB1_pin={} 
    d_r_SHR1_pin={} 
    d_r_HB2_pin={} 
    d_r_SHR2_pin={} 
    d_r_d_result_HB_pin={} 
    d_r_d_result_SHR_pin={}

    d_r_HB1_fix={}
    d_r_SHR1_fix={} 
    d_r_HB2_fix={} 
    d_r_SHR2_fix={} 
    d_r_d_result_HB_fix={} 
    d_r_d_result_SHR_fix={}

    d_r_HB1_hjs={} 
    d_r_SHR1_hjs={} 
    d_r_HB2_hjs={} 
    d_r_SHR2_hjs={} 
    d_r_d_result_HB_hjs={} 
    d_r_d_result_SHR_hjs={}
    d_r_Result_HJ_hjs={}

    d_r_fallaContinouos={}
    d_r_St_type={}



    ####return variables#####
    d_r_text_HB={}
    d_r_text_m_HB={}

    d_r_text_SHR={}
    d_r_text_m_SHR={}
    d_current_status={}
    d_StructureKey={}

    d_r_text_HB_pin={}
    d_r_text_SHR_pin={}
    d_current_status_pin={}

    d_r_text_HB_fix={}
    d_r_text_SHR_fix={}
    d_current_status_fix={}
    d_fallaContinouos={}

    d_r_text_HB_hjs={}
    d_r_text_SHR_hjs={}

    d_current_status_hb={}
    d_current_status_shr={}

    d_sf={}
    d_estructure_Type_convert={}

    d_current_status_hb_hjs={}
    d_current_status_shr_hjs={}

    d_extra_check_hj={}

    d_ldds_f={}
    d_ldds_position_f={}




    for T_E in range (1, total_structures+1):
        d_StructureKey[T_E]=StructureKey[T_E-1]
        print(StructureKey[T_E-1])
        globalvariables()   

        workssheetLB4coma2masI=d_workssheetLB4coma2masI[T_E]
        workssheetLB5coma2masI=d_workssheetLB5coma2masI[T_E]
        HB_or_SV=d_HB_or_SV[T_E]
        if(HB_or_SV=='HB'):
            HB_rating=d_HB_or_SV_value[T_E]
        elif(HB_or_SV=='SV'):
            Reserve_Factor=d_HB_or_SV_value[T_E]
            SV_Rating=d_Span_SVRating[T_E]




        if StructureType[T_E-1]=="box culvert":
            St_type="2"
        elif StructureType[T_E-1]=="cable stayed bridge":
            St_type="1"
        elif StructureType[T_E-1]=="multi span bridge":
            St_type="1"
        elif StructureType[T_E-1]=="continuous span bridge":
            St_type="1"
        elif StructureType[T_E-1]=="integral structure":
            St_type="1"
        elif StructureType[T_E-1]=="portal frame":
            St_type="2"
        elif StructureType[T_E-1]=="simply supported span":
            St_type="3"
        elif StructureType[T_E-1]=="suspension bridge":
            St_type="1"
        elif StructureType[T_E-1]=="lift":
            St_type="3"
        elif StructureType[T_E-1]=="swing":
            St_type="3"
        elif StructureType[T_E-1]=="pipe":
            St_type="3"

        #########check if it is Half-Joint#######
        
        ishalfjoint,ldds_f,Ldds_position_f=databaseSimulate(StructureKey[T_E-1])
        if (ishalfjoint==1):
            St_type="4"
            d_ldds_f[T_E]=ldds_f
            d_ldds_position_f[T_E]=Ldds_position_f
            Ldds=ldds_f
            Ldds_position=Ldds_position_f
        else:
            Ldds=0
            Ldds_position=0



        

        print("Structure type:")
        print("1. Continuous")
        print("2. Box/Frame")
        print("3. Simply-Supported")
        print("4. Half-Joint")
        print("Calculando...")
        print(StructureType[T_E-1])
        print(St_type)

        d_r_St_type[T_E]=St_type
        d_sf[T_E]=sf


        if(St_type=="1"):      
            d_estructure_Type_convert[T_E]='Continuous'     
            #####botones#####3
            OPTlhfixed=0
            OPTlhpin=1
            OPTrhfixed=0
            OPTrhpin=1           


            PREPARE_CALCS()

            if(HB_or_SV=="HB"):
                MaxMoveMomHB1,MaxMoveShrHB1=Load_Vehicle_HB_Fact()
            elif(HB_or_SV=='SV'):
                MaxMoveMomHB1,MaxMoveShrHB1=Load_Vehicle_SV_Fact()

            for I in range(1, 26):
                for J in range(1, 7):
                    MaxMoveMomHB11[I, J] = MaxMoveMomHB1[I, J]

            for I in range(1, 26):
                for J in range(1, 6):
                    MaxMoveShrHB11[I, J] = MaxMoveShrHB1[I, J]

            L=np.zeros(11)
            EIStrt=np.zeros(11)
            Lleft=np.zeros(11)
            EI=np.zeros(11)
            KEI=np.zeros((11,3))
            FEM=np.zeros((11,3))
            Vehicle=np.zeros((51,3))
            Loadin=np.zeros((6,101))
            FEM1=np.zeros((11,3))
            FEM2=np.zeros((11,3))
            Rv=np.zeros(12)
            MaxMoveMomHB=np.zeros((26,7))        
            MaxMoveShrHB=np.zeros((26,6))
            workssheetLB6coma2masI=np.zeros(11)
            MaxMoveMom=np.zeros((43,4))
            MaxMoveShr=np.zeros((26,3))
            OpeninFlag=0########?????
            
            workssheetLB3coma2masI=np.zeros(11)


            PREPARE_CALCS()
            MaxMoveMomHB2, MaxMoveShrHB2=Load_Axles_AIL()

            for I in range(1, 26):
                for J in range(1, 7):
                    MaxMoveMomHB22[I, J] = MaxMoveMomHB2[I, J]

            for I in range(1, 26):
                for J in range(1, 6):
                    MaxMoveShrHB22[I, J] = MaxMoveShrHB2[I, J]


            HB1, SHR1, HB2, SHR2, d_result_HB, d_result_SHR =comparative(MaxMoveMomHB11, MaxMoveMomHB22,MaxMoveShrHB11,MaxMoveShrHB22)

            d_r_HB1[T_E]=HB1
            d_r_SHR1[T_E]=SHR1
            d_r_HB2[T_E]=HB2
            d_r_SHR2[T_E]=SHR2
            d_r_d_result_HB[T_E]=d_result_HB
            d_r_d_result_SHR[T_E]=d_result_SHR

           

            ##################################### RETURN VALUES ########################            
            ######## HB1 ########
            v_text_m_HB=[]
            i=1           
            nciclos=int(len(d_r_HB1[T_E])/2)
            for i in range(1,nciclos+1):
                a="Mom at sup " + str(i)
                b="Mom at span " + str(i)
                v_text_m_HB.append(a)
                v_text_m_HB.append(b)
            c="Mom at sup " + str(i+1)
            v_text_m_HB.append(c)

            d_r_text_HB[T_E]=v_text_m_HB


            ###### SHR1 #####
            v_text_m_SHR=[]
            i=1
            nciclos=int(len(d_r_SHR1[T_E])/2)
            for i in range(1,nciclos+1):
                a="Span " + str(i) + " left end"
                b="Span " + str(i) + " right end"
                v_text_m_SHR.append(a)
                v_text_m_SHR.append(b)

            d_r_text_SHR[T_E]=v_text_m_SHR

            fail_hb=0
            fail_shr=0
            fail=0
            for x in d_r_d_result_HB[T_E]:
                if (d_r_d_result_HB[T_E][x]=='FAIL'):
                    fail=1
                    fail_hb=1
            if fail_hb==1:
                d_current_status_hb[T_E]="FAIL"
            else:
                d_current_status_hb[T_E]="OK"

            for x in d_r_d_result_SHR[T_E]:
                if (d_r_d_result_SHR[T_E][x]=='FAIL'):
                    fail=1
                    fail_shr=1

            if fail_shr==1:
                d_current_status_shr[T_E]="FAIL"
            else:
                d_current_status_shr[T_E]="OK"

            if fail==1:
                d_current_status[T_E]="FAIL"
            else:
                d_current_status[T_E]="OK"
                    
        if(St_type=="2"):  
            d_estructure_Type_convert[T_E]='Box/Frame'   
            
            #####botones#####
            OPTlhfixed=0
            OPTlhpin=1
            OPTrhfixed=0
            OPTrhpin=1        

            Factored=1
            NoOF=0
            NoDF=0
            NoFact=0

            PREPARE_CALCS()
            if(HB_or_SV=="HB"):
                MaxMoveMomHB1,MaxMoveShrHB1=Load_Vehicle_HB_Fact()
            elif(HB_or_SV=='SV'):
                MaxMoveMomHB1,MaxMoveShrHB1=Load_Vehicle_SV_Fact()

            for I in range(1, 26):
                for J in range(1, 7):
                    MaxMoveMomHB11[I, J] = MaxMoveMomHB1[I, J]
            for I in range(1, 26):
                for J in range(1, 6):
                    MaxMoveShrHB11[I, J] = MaxMoveShrHB1[I, J]

            L=np.zeros(11)
            EIStrt=np.zeros(11)
            Lleft=np.zeros(11)
            EI=np.zeros(11)
            KEI=np.zeros((11,3))
            FEM=np.zeros((11,3))
            Vehicle=np.zeros((51,3))
            Loadin=np.zeros((6,101))
            FEM1=np.zeros((11,3))
            FEM2=np.zeros((11,3))
            Rv=np.zeros(12)
            MaxMoveMomHB=np.zeros((26,7))
            MaxMoveMomHB22=np.zeros((26,7))
            
            MaxMoveShrHB=np.zeros((26,6))
            workssheetLB6coma2masI=np.zeros(11)
            MaxMoveMom=np.zeros((43,4))
            MaxMoveShr=np.zeros((26,3))        
            OpeninFlag=0########?????               
            workssheetLB3coma2masI=np.zeros(11)       



            PREPARE_CALCS()
            MaxMoveMomHB2,MaxMoveShrHB2=Load_Axles_AIL()

            for I in range(1, 25 + 1):
                for J in range(1, 7):
                    MaxMoveMomHB22[I, J] = MaxMoveMomHB2[I, J]
            for I in range(1, 25 + 1):
                for J in range(1, 6):
                    MaxMoveShrHB22[I, J] = MaxMoveShrHB2[I, J]
        
            print("*****************PINNED***********************")
            HB1_pin, SHR1_pin, HB2_pin, SHR2_pin, d_result_HB_pin, d_result_SHR_pin = comparative(MaxMoveMomHB11, MaxMoveMomHB22, MaxMoveShrHB11, MaxMoveShrHB22)

            d_r_HB1_pin[T_E]=HB1_pin
            d_r_SHR1_pin[T_E]=SHR1_pin
            d_r_HB2_pin[T_E]=HB2_pin
            d_r_SHR2_pin[T_E]=SHR2_pin
            d_r_d_result_HB_pin[T_E]=d_result_HB_pin
            d_r_d_result_SHR_pin[T_E]=d_result_SHR_pin



            ##################################### RETURN VALUES ########################            
            ######## HB1 ########
            v_text_m_HB=[]
            i=1           
            nciclos=int(len(d_r_HB1_pin[T_E])/2)
            for i in range(1,nciclos+1):
                a="Mom at sup " + str(i)
                b="Mom at span " + str(i)
                v_text_m_HB.append(a)
                v_text_m_HB.append(b)
            c="Mom at sup " + str(i+1)
            v_text_m_HB.append(c)

            d_r_text_HB_pin[T_E]=v_text_m_HB


            ###### SHR1 #####
            v_text_m_SHR=[]
            i=1
            nciclos=int(len(d_r_SHR1_pin[T_E])/2)
            for i in range(1,nciclos+1):
                a="Span " + str(i) + " left end"
                b="Span " + str(i) + " right end"
                v_text_m_SHR.append(a)
                v_text_m_SHR.append(b)

            d_r_text_SHR_pin[T_E]=v_text_m_SHR


            fail=0
            for x in d_r_d_result_HB_pin[T_E]:
                if (d_r_d_result_HB_pin[T_E][x]=='FAIL'):
                    fail=1
            for x in d_r_d_result_SHR_pin[T_E]:
                if (d_r_d_result_SHR_pin[T_E][x]=='FAIL'):
                    fail=1
            if fail==1:
                d_current_status_pin[T_E]="FAIL"
            else:
                d_current_status_pin[T_E]="OK"






            L=np.zeros(11)
            EIStrt=np.zeros(11)
            Lleft=np.zeros(11)
            EI=np.zeros(11)
            KEI=np.zeros((11,3))
            FEM=np.zeros((11,3))
            Vehicle=np.zeros((51,3))
            Loadin=np.zeros((6,101))
            FEM1=np.zeros((11,3))
            FEM2=np.zeros((11,3))
            Rv=np.zeros(12)
            MaxMoveMomHB=np.zeros((26,7))
            MaxMoveMomHB11=np.zeros((26,7))
            MaxMoveMomHB22=np.zeros((26,7))        
            MaxMoveShrHB=np.zeros((26,6))
            workssheetLB6coma2masI=np.zeros(11)
            MaxMoveMom=np.zeros((43,4))
            MaxMoveShr=np.zeros((26,3))
            OpeninFlag=0

            #####botones#####3
            OPTlhfixed=1
            OPTlhpin=0
            OPTrhfixed=1
            OPTrhpin=0
            
            workssheetLB3coma2masI=np.zeros(11)


            PREPARE_CALCS()

            if(HB_or_SV=="HB"):
                MaxMoveMomHB1,MaxMoveShrHB1=Load_Vehicle_HB_Fact()
            elif(HB_or_SV=='SV'):
                MaxMoveMomHB1,MaxMoveShrHB1=Load_Vehicle_SV_Fact()

            for I in range(1, 25 + 1):
                for J in range(1, 7):
                    MaxMoveMomHB11[I, J] = MaxMoveMomHB1[I, J]
            for I in range(1, 25 + 1):
                for J in range(1, 6):
                    MaxMoveShrHB11[I, J] = MaxMoveShrHB1[I, J]

            L=np.zeros(11)
            EIStrt=np.zeros(11)
            Lleft=np.zeros(11)
            EI=np.zeros(11)
            KEI=np.zeros((11,3))
            FEM=np.zeros((11,3))
            Vehicle=np.zeros((51,3))
            Loadin=np.zeros((6,101))
            FEM1=np.zeros((11,3))
            FEM2=np.zeros((11,3))
            Rv=np.zeros(12)
            MaxMoveMomHB=np.zeros((26,7))
            MaxMoveMomHB22=np.zeros((26,7))        
            MaxMoveShrHB=np.zeros((26,6))
            workssheetLB6coma2masI=np.zeros(11)
            MaxMoveMom=np.zeros((43,4))
            MaxMoveShr=np.zeros((26,3))
            OpeninFlag=0            
            workssheetLB3coma2masI=np.zeros(11)


            PREPARE_CALCS()
            MaxMoveMomHB2,MaxMoveShrHB2=Load_Axles_AIL()

            for I in range(1, 25 + 1):
                for J in range(1, 7):
                    MaxMoveMomHB22[I, J] = MaxMoveMomHB2[I, J]
            for I in range(1, 25 + 1):
                for J in range(1, 6):
                    MaxMoveShrHB22[I, J] = MaxMoveShrHB2[I, J]
        
            print("*****************FIXED***********************")
            HB1_fix, SHR1_fix, HB2_fix, SHR2_fix, d_result_HB_fix, d_result_SHR_fix=comparative(MaxMoveMomHB11, MaxMoveMomHB22,MaxMoveShrHB11, MaxMoveShrHB22)

            d_r_HB1_fix[T_E]=HB1_fix
            d_r_SHR1_fix[T_E]=SHR1_fix
            d_r_HB2_fix[T_E]=HB2_fix
            d_r_SHR2_fix[T_E]=SHR2_fix
            d_r_d_result_HB_fix[T_E]=d_result_HB_fix
            d_r_d_result_SHR_fix[T_E]=d_result_SHR_fix

            ##################################### RETURN VALUES ########################            
            ######## HB1 ########
            v_text_m_HB=[]
            i=1           
            nciclos=int(len(d_r_HB1_fix[T_E])/2)
            for i in range(1,nciclos+1):
                a="Mom at sup " + str(i)
                b="Mom at span " + str(i)
                v_text_m_HB.append(a)
                v_text_m_HB.append(b)
            c="Mom at sup " + str(i+1)
            v_text_m_HB.append(c)

            d_r_text_HB_fix[T_E]=v_text_m_HB


            ###### SHR1 #####
            v_text_m_SHR=[]
            i=1
            nciclos=int(len(d_r_SHR1_pin[T_E])/2)
            for i in range(1,nciclos+1):
                a="Span " + str(i) + " left end"
                b="Span " + str(i) + " right end"
                v_text_m_SHR.append(a)
                v_text_m_SHR.append(b)

            d_r_text_SHR_fix[T_E]=v_text_m_SHR


            fail=0
            for x in d_r_d_result_HB_fix[T_E]:
                print(x)
                if (d_r_d_result_HB_fix[T_E][x]=='FAIL'):
                    fail=1

            for x in d_r_d_result_SHR_fix[T_E]:
                print(x)
                if (d_r_d_result_SHR_fix[T_E][x]=='FAIL'):
                    fail=1
            if fail==1:
                d_current_status_fix[T_E]="FAIL"
            else:
                d_current_status_fix[T_E]="OK"




            fail_hb=0
            fail_shr=0
            fail=0
            for x in d_r_d_result_HB_pin[T_E]:
                if (d_r_d_result_HB_pin[T_E][x]=='FAIL'):
                    fail=1
                    fail_hb=1
            for x in d_r_d_result_HB_fix[T_E]:
                if (d_r_d_result_HB_fix[T_E][x]=='FAIL'):
                    fail=1
                    fail_hb=1
            if fail_hb==1:
                d_current_status_hb[T_E]="FAIL"
            else:
                d_current_status_hb[T_E]="OK"

            for x in d_r_d_result_SHR_pin[T_E]:
                if (d_r_d_result_SHR_pin[T_E][x]=='FAIL'):
                    fail=1
                    fail_shr=1
            for x in d_r_d_result_SHR_fix[T_E]:
                if (d_r_d_result_SHR_fix[T_E][x]=='FAIL'):
                    fail=1
                    fail_shr=1
            if fail_shr==1:
                d_current_status_shr[T_E]="FAIL"
            else:
                d_current_status_shr[T_E]="OK"

            if (fail_hb==1 or fail_shr==1):
                d_current_status[T_E]='FAIL'
            else:
                d_current_status[T_E]='OK'



        if(St_type=="3"):     
            d_estructure_Type_convert[T_E]='Simply-Supported'
            Simply_Supported=1

            L=np.zeros(11)
            EIStrt=np.zeros(11)
            Lleft=np.zeros(11)
            EI=np.zeros(11)
            KEI=np.zeros((11,3))
            FEM=np.zeros((11,3))
            Vehicle=np.zeros((51,3))
            Loadin=np.zeros((6,101))
            FEM1=np.zeros((11,3))
            FEM2=np.zeros((11,3))
            Rv=np.zeros(12)
            MaxMoveMomHB=np.zeros((26,7))
            MaxMoveMomHB11=np.zeros((26,7))
            MaxMoveMomHB22=np.zeros((26,7))        
            MaxMoveShrHB=np.zeros((26,6))
            workssheetLB6coma2masI=np.zeros(11)
            MaxMoveMom=np.zeros((43,4))
            MaxMoveShr=np.zeros((26,3))
            OpeninFlag=0
            #####botones#####
            OPTlhfixed=0
            OPTlhpin=1
            OPTrhfixed=0
            OPTrhpin=1
            #################        
            workssheetLB3coma2masI=np.zeros(11)

            PREPARE_CALCS()
            v_HB1, v_SHR1, v_HB2, v_SHR2, v_d_result_HB, v_d_result_SHR=CALC_SS_HB_AIL() 

            d_r_HB1[T_E]=v_HB1
            d_r_SHR1[T_E]=v_SHR1
            d_r_HB2[T_E]=v_HB2
            d_r_SHR2[T_E]=v_SHR2
            d_r_d_result_HB[T_E]=v_d_result_HB
            d_r_d_result_SHR[T_E]=v_d_result_SHR   

            
            fail=0
            fail_hb=0
            fail_shr=0
            for x in range(0,len(d_r_d_result_HB[T_E])):
                for xx in range(0,len(d_r_d_result_HB[T_E][x])):
                    if (d_r_d_result_HB[T_E][x][xx]=='FAIL'):
                        fail=1
                        fail_hb=1
            if fail_hb==1:
                d_current_status_hb[T_E]="FAIL"
            else:
                d_current_status_hb[T_E]="OK"

            for x in range(0,len(d_r_d_result_SHR[T_E])):
                for xx in range(0,len(d_r_d_result_SHR[T_E][x])):
                    if (d_r_d_result_SHR[T_E][x][xx]=='FAIL'):
                        fail=1
                        fail_shr=1
            if fail_shr==1:
                d_current_status_shr[T_E]="FAIL"
            else:
                d_current_status_shr[T_E]="OK"
            if fail==1:
                d_current_status[T_E]="FAIL"
            else:
                d_current_status[T_E]="OK"


            print(d_current_status_shr[T_E])
            print(d_r_d_result_SHR[T_E])


            #################################  RETURN  VALUES  ########################
            

            ###### HB1 #####
            v_text_m_HB=[]
            i=1

            for y in range(0,len(d_r_HB1[T_E])):  
                nciclos=int(len(d_r_HB1[T_E][y])/2)
                for i in range(1,nciclos+1):
                    a="Mom at sup " + str(y+1)
                    b="Mom at span " + str(y+1)
                    v_text_m_HB.append(a)
                    v_text_m_HB.append(b)
                c="Mom at sup " + str(y+1+1)
                v_text_m_HB.append(c)
                d_r_text_m_HB[y]=v_text_m_HB
                v_text_m_HB=[]

            d_r_text_HB[T_E]=d_r_text_m_HB
            d_r_text_m_HB={}

            ###### SHR1 #####

            v_text_m_SHR=[]
            i=1
            for y in range(0,len(d_r_SHR1[T_E])):             
                nciclos=int(len(d_r_SHR1[T_E][y])/2)
                for i in range(1,nciclos+1):
                    a="Span " + str(y+1) + " left end"
                    b="Span " + str(y+1) + " right end"
                    v_text_m_SHR.append(a)
                    v_text_m_SHR.append(b)
                d_r_text_m_SHR[y]=v_text_m_SHR
                v_text_m_SHR=[]

            d_r_text_SHR[T_E]=d_r_text_m_SHR
            d_r_text_m_SHR={}

        if(St_type=="4"):
            d_estructure_Type_convert[T_E]='Half-Joint'

            OPTlhfixed=0
            OPTlhpin=1
            OPTrhfixed=0
            OPTrhpin=1 

            PREPARE_CALCS()
            if(HB_or_SV=="HB"):
                MaxMoveMomHB1,MaxMoveShrHB1=Load_Vehicle_HB_Fact()
            elif(HB_or_SV=='SV'):
                MaxMoveMomHB1,MaxMoveShrHB1=Load_Vehicle_SV_Fact()

            for I in range(1, 26):
                for J in range(1, 7):
                    MaxMoveMomHB11[I, J] = MaxMoveMomHB1[I, J]

            for I in range(1, 26):
                for J in range(1, 6):
                    MaxMoveShrHB11[I, J] = MaxMoveShrHB1[I, J]

            L=np.zeros(11)
            EIStrt=np.zeros(11)
            Lleft=np.zeros(11)
            EI=np.zeros(11)
            KEI=np.zeros((11,3))
            FEM=np.zeros((11,3))
            Vehicle=np.zeros((51,3))
            Loadin=np.zeros((6,101))
            FEM1=np.zeros((11,3))
            FEM2=np.zeros((11,3))
            Rv=np.zeros(12)
            MaxMoveMomHB=np.zeros((26,7))
            
            MaxMoveShrHB=np.zeros((26,6))
            workssheetLB6coma2masI=np.zeros(11)
            MaxMoveMom=np.zeros((43,4))
            MaxMoveShr=np.zeros((26,3))
            OpeninFlag=0########?????        
            workssheetLB3coma2masI=np.zeros(11)

            PREPARE_CALCS()
            MaxMoveMomHB2, MaxMoveShrHB2=Load_Axles_AIL()

            for I in range(1, 26):
                for J in range(1, 7):
                    MaxMoveMomHB22[I, J] = MaxMoveMomHB2[I, J]

            for I in range(1, 26):
                for J in range(1, 6):
                    MaxMoveShrHB22[I, J] = MaxMoveShrHB2[I, J]


            HB1, SHR1, HB2, SHR2, d_result_HB, d_result_SHR = comparative(MaxMoveMomHB11, MaxMoveMomHB22,MaxMoveShrHB11,MaxMoveShrHB22)

            d_r_HB1[T_E]=HB1
            d_r_SHR1[T_E]=SHR1
            d_r_HB2[T_E]=HB2
            d_r_SHR2[T_E]=SHR2
            d_r_d_result_HB[T_E]=d_result_HB
            d_r_d_result_SHR[T_E]=d_result_SHR


            ##################################### RETURN VALUES ########################            
            ######## HB1 ########
            v_text_m_HB=[]
            i=1           
            nciclos=int(len(d_r_HB1[T_E])/2)
            for i in range(1,nciclos+1):
                a="Mom at sup " + str(i)
                b="Mom at span " + str(i)
                v_text_m_HB.append(a)
                v_text_m_HB.append(b)
            c="Mom at sup " + str(i+1)
            v_text_m_HB.append(c)

            d_r_text_HB[T_E]=v_text_m_HB


            ###### SHR1 #####
            v_text_m_SHR=[]
            i=1
            nciclos=int(len(d_r_SHR1[T_E])/2)
            for i in range(1,nciclos+1):
                a="Span " + str(i) + " left end"
                b="Span " + str(i) + " right end"
                v_text_m_SHR.append(a)
                v_text_m_SHR.append(b)

            d_r_text_SHR[T_E]=v_text_m_SHR
            ##################################### END RETURN VALUES ######################## 




            ##IF COUNTINOUS WORKS##    DO JUST ONE SIMPLY SUPPORTED

            fail=0
            fail_hb=0
            fail_shr=0
            fallaContinouos=0
            for x in d_r_d_result_HB[T_E]:
                if (d_r_d_result_HB[T_E][x]=='FAIL'):
                    fail=1
                    fail_hb=1
            for x in d_r_d_result_SHR[T_E]:
                if (d_r_d_result_SHR[T_E][x]=='FAIL'):
                    fail=1
                    fail_shr=1


            if fail_hb==1:
                d_current_status_hb[T_E]='FAIL'
            else:
                d_current_status_hb[T_E]='OK'

            if fail_shr==1:
                d_current_status_shr[T_E]='FAIL'
            else:
                d_current_status_shr[T_E]='OK'

            if (fail==0):
                d_fallaContinouos[T_E]='OK'
                HB1_hjs, SHR1_hjs, HB2_hjs, SHR2_hjs, d_result_HB_hjs, d_result_SHR_hjs,Result_HJ_hjs, Vcant1, Vcant2, Mcant1, Mcant2=HalfJointedSpan(HB_or_SV)
                v_extra_check_hj=np.zeros((1,4))
                v_extra_check_hj[0][0]=round(Vcant1,1)
                v_extra_check_hj[0][1]=round(Vcant2,1)
                v_extra_check_hj[0][2]=round(Mcant1,1)
                v_extra_check_hj[0][3]=round(Mcant2,1)
                d_extra_check_hj[T_E]=v_extra_check_hj

            else:
                fallaContinouos=1
                d_fallaContinouos[T_E]='FAIL'

    
            if (fail==0 and valid_data==1):
                d_r_HB1_hjs[T_E]=HB1_hjs
                d_r_SHR1_hjs[T_E]=SHR1_hjs 
                d_r_HB2_hjs[T_E]=HB2_hjs
                d_r_SHR2_hjs[T_E]=SHR2_hjs
                d_r_d_result_HB_hjs[T_E]=d_result_HB_hjs
                d_r_d_result_SHR_hjs[T_E]=d_result_SHR_hjs
                d_r_Result_HJ_hjs[T_E]=Result_HJ_hjs

                ##################################### RETURN VALUES ########################            
                ######## HB1 ########
                v_text_m_HB=[]
                i=1           
                nciclos=int(len(d_r_HB1_hjs[T_E])/2)
                for i in range(1,nciclos+1):
                    a="Mom at sup " + str(i)
                    b="Mom at span " + str(i)
                    v_text_m_HB.append(a)
                    v_text_m_HB.append(b)
                c="Mom at sup " + str(i+1)
                v_text_m_HB.append(c)

                d_r_text_HB_hjs[T_E]=v_text_m_HB


                ###### SHR1 #####
                v_text_m_SHR=[]
                i=1
                nciclos=int(len(d_r_SHR1[T_E])/2)
                for i in range(1,2):
                    a="Span " + str(i) + " left end"
                    b="Span " + str(i) + " right end"
                    v_text_m_SHR.append(a)
                    v_text_m_SHR.append(b)

                d_r_text_SHR_hjs[T_E]=v_text_m_SHR
                

                #### if ok o fail
                fail_hjs=0
                fail_hb_hjs=0
                fail_shr_hjs=0
                for x in d_r_d_result_HB_hjs[T_E]:
                    if (d_r_d_result_HB_hjs[T_E][x]=='FAIL'):
                        fail_hjs=1
                        fail_hb_hjs=1
                for x in d_r_d_result_SHR_hjs[T_E]:
                    if (d_r_d_result_SHR_hjs[T_E][x]=='FAIL'):
                        fail_hjs=1
                        fail_shr_hjs=1
                if fail_hjs==1:
                    d_current_status[T_E]="FAIL"
                else:
                    d_current_status[T_E]="OK"


                if fail_hb_hjs==1:
                    d_current_status_hb_hjs[T_E]='FAIL'
                else:
                    d_current_status_hb_hjs[T_E]='OK'
                if fail_shr_hjs==1 :
                    d_current_status_shr_hjs[T_E]='FAIL'
                else:
                    d_current_status_shr_hjs[T_E]='OK'

                if Result_HJ_hjs=='FAIL':
                    d_current_status[T_E]="FAIL"

            else:
                d_current_status[T_E]="FAIL"


                


        

    
    


    notice_reference=notice_reference[0]
    vehicle_assessed=vehicle_assessed[0]
    
   
    global_fail=0

    for x in range(1,total_structures+1):
        if (d_current_status[x]=='FAIL'):
            global_fail=1
    if global_fail==0:
        global_status='OK'
    else:
        global_status='FAIL'

    writejson()


    
    data={}
    esdalstructureresults={}

    # for i in range(1,total_structures+1):
    #     str_current_status= d_current_status[i]
    #     str_current_status_hb= d_current_status_hb[i]
    #     str_current_status_shr= d_current_status_shr[i]
    #     esdalstructureresults['EsdalStructure ' + str(i)] = []
    #     esdalstructureresults['EsdalStructure ' + str(i)].append({        
    #     "StructureKey":StructureKey[i-1] ,
    #     "structureType":d_estructure_Type_convert[i],
    #     "result structure":str_current_status ,
    #     "result mom":str_current_status_hb,
    #     "result shear":str_current_status_shr
    #     })

    
    # data['properties'] = []
    # data['properties'].append({
    # "movement_id":notice_reference ,
    # "global result": global_status,
    # "comments":" ",
    # "sf":sf})

    # data['properties'].append(esdalstructureresults)
    # collection.insert_one(data)


    matrix_output=[[None for c in range(3)] for r in range(total_structures)]
    i=-1
    for key in d_StructureKey:
        i=i+1
        matrix_output[i][0]=key
        matrix_output[i][1]=d_StructureKey[key]

    i=-1
    for key in d_current_status:
        i=i+1
        matrix_output[i][2]=d_current_status[key]








    
    return render(request, 'summary.html',{'matrix_output':matrix_output,'global_status':global_status})
    # return render(request, 'summary.html',{'d_StructureKey':d_StructureKey, 'd_current_status':d_current_status,'global_status':global_status ,'d_HB_or_SV':d_HB_or_SV, 'd_HB_or_SV_value':d_HB_or_SV_value,  'notice_reference':notice_reference,'d_r_St_type':d_r_St_type, 'd_r_HB1':d_r_HB1, 'd_r_text_HB':d_r_text_HB,\
    # 'd_r_HB2':d_r_HB2, 'd_r_d_result_HB':d_r_d_result_HB,'d_r_SHR1':d_r_SHR1 ,'d_r_text_SHR':d_r_text_SHR, 'd_r_SHR2':d_r_SHR2, 'd_r_d_result_SHR':d_r_d_result_SHR,\
    # 'vehicle_assessed':vehicle_assessed, 'd_r_text_HB_pin':d_r_text_HB_pin,'d_r_text_SHR_pin': d_r_text_SHR_pin, 'd_r_HB1_pin':d_r_HB1_pin,'d_r_SHR1_pin':d_r_SHR1_pin,\
    # 'd_r_HB2_pin':d_r_HB2_pin, 'd_r_SHR2_pin':d_r_SHR2_pin, 'd_r_d_result_HB_pin': d_r_d_result_HB_pin,'d_r_d_result_SHR_pin': d_r_d_result_SHR_pin,\
    # 'd_r_text_HB_fix':d_r_text_HB_fix,'d_r_text_SHR_fix': d_r_text_SHR_fix, 'd_r_HB1_fix':d_r_HB1_fix,'d_r_SHR1_fix':d_r_SHR1_fix, 'd_r_HB2_fix':d_r_HB2_fix,\
    # 'd_r_SHR2_fix':d_r_SHR2_fix, 'd_r_d_result_HB_fix': d_r_d_result_HB_fix, 'd_r_d_result_SHR_fix': d_r_d_result_SHR_fix, 'd_fallaContinouos':d_fallaContinouos,\
    # 'd_r_HB1_hjs':d_r_HB1_hjs, 'd_r_SHR1_hjs':d_r_SHR1_hjs, 'd_r_HB2_hjs':d_r_HB2_hjs, 'd_r_SHR2_hjs':d_r_SHR2_hjs, 'd_r_d_result_HB_hjs':d_r_d_result_HB_hjs,\
    # 'd_r_d_result_SHR_hjs':d_r_d_result_SHR_hjs, 'd_r_Result_HJ_hjs':d_r_Result_HJ_hjs, 'd_r_text_HB_hjs': d_r_text_HB_hjs, 'd_r_text_SHR_hjs':d_r_text_SHR_hjs,\
    # 'd_current_status_hb':d_current_status_hb, 'd_current_status_shr':d_current_status_shr, 'd_sf':d_sf, 'd_Span_SVRating':d_Span_SVRating,'d_estructure_Type_convert':d_estructure_Type_convert})

    #return d_r_St_type,d_r_HB1,d_r_SHR1,d_r_HB2,d_r_SHR2,d_r_d_result_HB,d_r_d_result_SHR,d_r_HB1_pin,d_r_SHR1_pin,d_r_HB2_pin,d_r_SHR2_pin,d_r_d_result_HB_pin,d_r_d_result_SHR_pin,d_r_HB1_fix,d_r_SHR1_fix,d_r_HB2_fix,d_r_SHR2_fix,d_r_d_result_HB_fix,d_r_d_result_SHR_fix,d_r_HB1_hjs,d_r_SHR1_hjs,d_r_HB2_hjs,d_r_SHR2_hjs,d_r_d_result_HB_hjs,d_r_d_result_SHR_hjs,d_r_Result_HJ_hjs,d_r_fallaContinouos



    
    
    
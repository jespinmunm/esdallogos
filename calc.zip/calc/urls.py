from django.urls import path
from . import views_comunicacionEsdal

urlpatterns=[
	path('',views_comunicacionEsdal.home, name='home'),
	path('start', views_comunicacionEsdal.start, name="start"),
	path('command', views_comunicacionEsdal.command, name="command"),
	path('recalculate', views_comunicacionEsdal.recalculate, name="recalculate"),
	path('summary_recalculate', views_comunicacionEsdal.summary_recalculate, name="summary_recalculate"),
	path('login_view', views_comunicacionEsdal.login_view, name="login_view"),
	#path('test', views_comunicacionEsdal.test, name="test"),
	path('command_json', views_comunicacionEsdal.command_json, name="command_json"),
	path('recalculate_previous', views_comunicacionEsdal.recalculate_previous, name="recalculate_previous"),
	path('summary', views_comunicacionEsdal.summary, name="summary"),
	path('logout_view', views_comunicacionEsdal.logout_view, name="logout_view"),
	path('home3', views_comunicacionEsdal.home3, name="home3"),
	path('gotocreatejsonmodule', views_comunicacionEsdal.gotocreatejsonmodule, name="gotocreatejsonmodule"),
	path('createjsonmodule_esdal', views_comunicacionEsdal.createjsonmodule_esdal, name="createjsonmodule_esdal"),
	path('createjsonmodule_email', views_comunicacionEsdal.createjsonmodule_email, name="createjsonmodule_email"),

]

# Create your views here.

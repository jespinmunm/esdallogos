/* Scripts */

function hole() {
    document.getElementById("holeModal").style.visibility="hidden";
    document.getElementById("loader").style.visibility="visible";
    document.getElementById("formulario").submit();
}